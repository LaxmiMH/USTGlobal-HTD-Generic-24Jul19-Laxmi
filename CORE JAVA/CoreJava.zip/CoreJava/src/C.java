import java.math.BigDecimal;

public class C {
	static int i=9;
	static int j=20;
	
	public static void main(String[] args) {
		
i++;	
System.out.println(i);
System.out.println(i++);
i++;
System.out.println(++i);
System.out.println(i++);
System.out.println(i++);
i++;
System.out.println(i++);

double a=0.02;
double b=0.03;
double c=b-a;
System.out.println(c);
BigDecimal d = new BigDecimal("0.02");
BigDecimal e= new BigDecimal("0.03");
BigDecimal f=e.subtract(d);
System.out.println(f);

int sum=0;
for(int i=0,j=0;i<5 & j<5;++i,j=i+1) {
	sum+=i;
}

System.out.println(sum);	}

}
