package com.dev.pract;

public class A {
public static void main(String[] args) {
	int [] a= {10,20,30};
	System.out.println(a);
	
}
}
