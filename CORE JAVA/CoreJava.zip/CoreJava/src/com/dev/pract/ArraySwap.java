package com.dev.pract;

import java.util.Scanner;

public class ArraySwap {
	public static void main(String[] args) {
		Scanner k = new Scanner(System.in);
		int a[]=new int[5];
		System.out.println("enter array");
		for(int i=1;i<a.length;i++) {
			a[i]=k.nextInt();
			try {
			if( a[i-1]>=a[i]   ) {
				int temp=a[i-1];
				a[i-1] = a[i];
				a[i]=temp;
			}
			
		}catch(Exception e) {
			System.out.println(a[i]);
	}
		System.out.println(a[i]);
		}
	}
}
			
