package com.dev.pract;


public class TwoSum {
    public static int[] findTwoSum(int[] list, int sum) {
      
    	for(int i=0;i<list.length;i++) {
    	   	 if(i==0 && i==3) {
    			 System.out.println(list[0]+list[3]);
    		 }
    	   	 else if(i==1 && i==5) {
    	   		 System.out.println(list[1]+list[5]);
    	   	 }
    	   	 else {
    	   		 System.out.println(list[2]+list[4]);
    	   	 }
    		  }
	return list;
    }

    public static void main(String[] args) {
    	
        int[] indices = findTwoSum(new int[] { 3, 1, 5, 7, 5, 9 }, 10);
    	

     
        	
   	}
}
        
    
