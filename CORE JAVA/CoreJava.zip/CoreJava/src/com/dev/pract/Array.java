package com.dev.pract;

import java.util.Scanner;

public class Array {
public static void main(String[] args) {
	int count=0;
	Scanner k = new Scanner(System.in);
	
	System.out.println("enter no of array elements");
	int n=k.nextInt();
	int [] arr = new int[n];
	System.out.println("enter elements");
//for(int i=0;i<n;i++) {
//
//	arr[i]=k.nextInt();
////	System.out.println(arr[i]);
//	
//	
//}

for(int i=0;i<n;i++) {

arr[i]=k.nextInt();
	System.out.println(arr[i]);
	
	
}


int m=0;
while(count<n) {
	if(arr[m]!=0)
	count++;
	m++;
	
}
System.out.println("count is;"+count);
}


}
