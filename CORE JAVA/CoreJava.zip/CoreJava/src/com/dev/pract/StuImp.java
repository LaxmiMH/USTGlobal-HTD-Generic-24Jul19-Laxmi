package com.dev.pract;

import java.util.HashMap;
import java.util.HashSet;

public class StuImp implements stu {
//HashSet<Student> hs=new HashSet<Student>();
	HashMap<String,Student> h = new HashMap<String,Student>();
//	@Override
//	public boolean addStudent(Student s) {
//		if(s!=null) {
//			hs.add(s);
//			return true;
//		}
//		return false;
//	}
//
//	@Override
//	public void getStudent() {
//		System.out.println(hs);
//		
//	}
//
//	@Override
//	public boolean removeStudent(Student s) {
//		boolean b=hs.remove(s);
//		if(b) {
//			return true;
//		}
//		return false;
//}

@Override
public Student addStudent(String k, Student s) {
 if(s!=null) {
	 h.put(k, s);
	 Student b = h.put(k, s);
	 if(b!=null) {
		 return s;
	 }
 }
	return null;
}

@Override
public void getStudent(String k) {
	System.out.println(h.get(k));;
}

@Override
public Student removeStudent(String k) {
	Student n=	h.remove(k);
	return n ;
}
	

}
