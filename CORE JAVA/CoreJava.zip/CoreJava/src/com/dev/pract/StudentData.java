package com.dev.pract;

public class StudentData {
public static void main(String[] args) {
	StuImp st=new StuImp();
	Student s=new Student();
	s.setName("shree");
	s.setAge(2);
	s.setPassword(1234);
	Student s1=new Student();
	s1.setName("shreedevi");
	s1.setAge(3);
	s1.setPassword(123);
	Student s2=new Student();
	s2.setName("shreedevi");
	s2.setAge(3);
	s2.setPassword(123);
	
Student b= st.addStudent("1", s);
Student b1= st.addStudent("2", s1);
System.out.println(b+" "+b1);
Student b2=st.removeStudent("1");
System.out.println(b2);
st.getStudent("2");

	
	
}
}

