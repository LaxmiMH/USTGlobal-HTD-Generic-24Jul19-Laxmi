package com.dev.pract;

public interface stu {
//public boolean addStudent(Student s);
	public Student addStudent(String k,Student s);
public void getStudent(String k);
public Student removeStudent(String k);
}
