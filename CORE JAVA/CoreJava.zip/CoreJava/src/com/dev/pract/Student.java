package com.dev.pract;

public class Student implements Comparable<Student> {

	private String name;
	private int age;
	private int password;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", age=" + age + ", password=" + "****" + "]";
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public void setPassword(int password) {
		this.password = password;
	}
	@Override
	public int compareTo(Student s) {
		
		return (this.age-s.age);
	}
	
	
	
}
