package com.dev.pract;

import java.util.ArrayList;
import java.util.TreeSet;

public class StudentTreeset {
	public static void main(String[] args) {
		ArrayList<Student> t=new ArrayList<Student>();
		Student s=new Student();
		s.setName("shree");
		s.setAge(1);
		s.setPassword(1234);
		
		Student s1=new Student();
		s1.setName("shreedevi");
		s1.setAge(2);
		s1.setPassword(1234);
		
		t.add(s);
		t.add(s1);
		System.out.println(t);
		
	}



}
