package com.dev.mine;

public class StringExample {

	public static void main(String[] args) {
		String s="hii";
		boolean b=s.isEmpty();
		System.out.println(b);
		String k="java";
		System.out.println(k.indexOf("j"));
		System.out.println(s+" "+k);
		char[] ch=s.toCharArray();
		System.out.println(ch);
		for( int i=0;i<ch.length;i++)
		{
			System.out.println(i);
			System.out.println(ch);
		}
		for(char c:ch) {
			System.out.println(c);
		}
		
	
		
	}

}
