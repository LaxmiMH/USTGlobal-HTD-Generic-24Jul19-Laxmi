package com.dev.mine;

public interface B {
	void add();
	

}
