package com.dev.mine;

import java.util.Scanner;

public class Student {
	public static void main(String[] args) {
		Scanner k=new Scanner(System.in);
		System.out.println("enter name: ");
		String name=k.next();
		System.out.println("enter percentage: ");
		float per= k.nextFloat();
		System.out.println("enter num : ");
		int num=k.nextInt();
		System.out.println("name is: "+name+"percentage is : "+per+"number is: "+num);
		 if(name.length()>=5) {
			 System.out.println("name length is >5");
		 }
		 else {System.out.println("length is < 5");}
		 
	}

	
	

}
