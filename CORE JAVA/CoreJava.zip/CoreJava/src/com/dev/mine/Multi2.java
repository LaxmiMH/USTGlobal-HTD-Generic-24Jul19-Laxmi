package com.dev.mine;

public class Multi2 {

	static String last="shree";
	static Multi2 m2=new Multi2();
	
	
	public void sum() {
		System.out.println("sum of numbers");
	}
	public static void main(String[] args) {
		System.out.println(m2.last);
	}
}
