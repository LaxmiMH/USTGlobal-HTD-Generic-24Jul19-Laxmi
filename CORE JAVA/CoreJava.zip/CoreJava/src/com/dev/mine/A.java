package com.dev.mine;

public interface A {

	void add();
	
}
