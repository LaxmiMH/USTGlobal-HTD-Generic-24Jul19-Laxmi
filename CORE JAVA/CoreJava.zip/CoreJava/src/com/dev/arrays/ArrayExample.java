package com.dev.arrays;

public class ArrayExample {

	public static void main(String[] args) {
		//declaration
		int [ ] intArr = new int[5]; //declaration and creation
		char[] charr;
		byte byteArr[];

		//creation
		//intArr = new int[5];  //max index is 4
		charr = new char[5];
		byteArr = new byte[5];

		//Initialization

		intArr[0] = 1;
		intArr[1] = 2;
		intArr[2] = 3;
		intArr[3] = 4;
		intArr[4] = 5;

		charr[0] = 'A';
		charr[1] = 'B';
		charr[2] = 'C';
		charr[3] = 'D';
		charr[4] = 'E';

		byteArr[0] = 10;
		byteArr[1] = 20;
		byteArr[2] = 30;
		byteArr[3] = 40;
		byteArr[4] = 50;
		
		char [] ch=new char[5];
		System.out.println(" "+ch);

		int res =intArr[1] * 3;               //to change the perticular data of an array
		System.out.println(res);

		res =intArr[1] + 3; 

		System.out.println(res);

		res =intArr[1] - 1; 

		System.out.println(res);

		res =intArr[1] / 3; 

		System.out.println(res);

		res =intArr[1] % 3; 

		System.out.println(res);
		System.out.println(charr[0] = 'A'+1 );
		  
		int[ ] intArr2 = {11, 22, 33, 44, 55};
		System.out.println(intArr2[4]);
		System.out.println("length of the 2nd array: "+intArr2.length);
		
		int [] intArr3 = {10,20,30,40,50};
		int a=5;
		for(int i=0;i<intArr3.length;i++) {
			if(intArr3[i]==a) {
				System.out.println("preset");
				break;
			}
			else {
				System.out.println("not found");
				break;
			}

		}
		int b=2;
		for(int i=0;i<intArr3.length;i++) {
			if(i==b) {
				System.out.println("b is valid index");
				for(int j=0;j<i;j++) {
					System.out.println(intArr3[j]);
					
				}
			}
			int m=0;
			int n=intArr3.length-2;
			//int midvalue= m+n/2;
			System.out.println(intArr3[n]);
			
		}
		
	}
	
	

}
