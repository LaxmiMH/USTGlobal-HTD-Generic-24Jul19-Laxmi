package com.dev.arrays;

public class ReverseArray {

	public static void main(String[] args) {
		//	int [] arr;
		//	arr=new int[5];
		int arr[] = {10,20,30,40,50};
		int i=arr.length;


		for(int j=i-1;j>=0;j--) {
			System.out.println(arr[j]);


		}



	}

}
