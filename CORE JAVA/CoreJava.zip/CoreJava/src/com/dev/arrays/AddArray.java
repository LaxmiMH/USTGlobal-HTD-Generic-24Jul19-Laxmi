package com.dev.arrays;

public class AddArray {

	public static void main(String[] args) {
		int arr[]= {10,20,30,40};
		int arr1[]= {20,30,40,20};
	int	l=arr.length;
	
	for(int i=l-1;i>=0;i--) {
	System.out.println(arr[i]);
	
		for(int j=0;j<=arr1.length;j++) {
		
		System.out.println(arr1[j]+arr[i]);
		}
	}
	
		

	}

}
