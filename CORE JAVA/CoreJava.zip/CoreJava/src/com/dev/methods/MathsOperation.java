package com.dev.methods;

public class MathsOperation {
	static MathsOperation ma=new MathsOperation();
	public int addition(int a,int b) {
		System.out.println("addition with 2 paraneters : "+" "+(a+b));
		return a+b;
	}
	public int addition(int a,int b,int c) {
		System.out.println("addition with 3 parameters : "+" "+(a+b+c));
		return a+b+c;
	}
	public int addition(int a,int b,int c,int d) {
		System.out.println("addition with 4 parameters : "+" "+(a+b+c+d));
		return a+b+c+d;
	}
	public int substraction(int c,int d) {
		System.out.println("substraction with 2 paraneters: "+" "+(c-d));
		return c-d;
	}
	public int substraction(int c,int d,int e) {
		System.out.println("substraction : "+" "+(c-d-e));
		return c-d-e;
	}
	public int substraction(int c,int d,int e,int f) {
		System.out.println("substraction : "+" "+(c-d-e-f));
		return c-d-e-f;
	}

	public int multiplication(int m,int n,int k) {
		System.out.println("multiplication with 2 paraneters: "+" "+m*n*k);
		return m*n*k;
	}
	public int multiplication(int m,int n) {
		System.out.println("multiplication : "+" "+m*n);
		return m*n;
	}
	public int multiplication(int m,int n,int k,int l) {
		System.out.println("multiplication : "+" "+m*n*k*l);
		return m*n*k*l;
	}
	public double division(double m,double  n,double k,double l) {
		System.out.println("division with 2 paraneters : "+" "+m/n/k/l);
		return m/n/k/l;
	}
	public double division(double m,double  n) {
		System.out.println("division : "+" "+m/n);
		return m/n;
	}
	public double division(double m,double  n,double k) {
		System.out.println("division : "+" "+m/n/k);
		return m/n/k;
	}

	public static void main(String[] args) {

		ma.addition(1, 2);
		ma.addition(1, 2, 3);
		ma.addition(1, 2, 5, 7);
		ma.substraction(5, 3);
		ma.substraction(11, 3, 2);
		ma.substraction(17, 2, 5, 1);
		ma.multiplication(3, 6);
		ma.multiplication(2, 3, 4);
		ma.multiplication(1, 2, 3, 4);
		ma.division(7.0, 2.0);
		ma.division(25, 2, 3);
		ma.division(1000, 10, 10, 1);


	}

}
