package com.dev.methods;

public class MethodExample1 {

	public static void main(String[] args) {
		int d=MethodExample.calArea(5);
		System.out.println(d);
		MethodExample me1=new MethodExample();
		int area=me1.AresRec(2, 4);
		System.out.println(area);

	}

}
