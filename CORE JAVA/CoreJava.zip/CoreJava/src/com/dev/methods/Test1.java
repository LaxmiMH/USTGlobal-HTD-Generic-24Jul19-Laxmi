package com.dev.methods;

public final class Test1 extends Demo{
	/*	
	 * 
	 * @Override
	  static void print() { //final methods cannot be override
		System.out.println("Test method");
		}
	 */

	public static void main(String[] args) {
		Demo.print();
	}

}
