package com.dev.methods;

public class MethodOverloading {
	static MethodOverloading mo=new MethodOverloading();
	public void print() {
		System.out.println("this is print method with no arg");
	}
	public int print(int i) {  
		System.out.println("this is method with arg");
		return 1;
	}         //arguments should be change

	static String print(String str) {
		System.out.println("this is method prints string arg");
		return "A";
	}
	final int print(float i) {
		System.out.println("hello");
		return 1;
	}
	public static void main(String[] args) {
		mo.print();
		mo.print(1);
		mo.print("a");
		mo.print(5f);
	}

}
