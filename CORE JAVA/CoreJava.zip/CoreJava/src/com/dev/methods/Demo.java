package com.dev.methods;

import com.dev.encapsulation.Dog; //import one class


public  class Demo {
/*
	Dog d = new Dog();  //import Dog class from encapsulation package
    com.dev.constructor.Dog d1= new com.dev.constructor.Dog();//fully collified class
*/
//final static  int INt=2;
	
	public static int i=10;
	public static String str="static string";
	
public static void print() {
	//System.out.println("Final method");
	System.out.println("static method");
}

public static void main(String[] args) {
  //INT=10;   final variable cannot be reinitilize
	//System.out.println(INT);
}

}
