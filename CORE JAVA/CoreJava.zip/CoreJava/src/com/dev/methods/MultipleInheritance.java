package com.dev.methods;

import com.dev.mine.A;
//import com.dev.mine.B;
import com.dev.mine.Multi2;

public class MultipleInheritance  extends Multi2 implements A  {

	static MultipleInheritance m1 = new MultipleInheritance();
	public static void main(String[] args) {
		MultipleInheritance m=new MultipleInheritance();
		m.add();
		m.sum();
		
		}

	@Override
	public void add() {
		System.out.println("both implemented");
		//System.out.println();
	}
	

}
