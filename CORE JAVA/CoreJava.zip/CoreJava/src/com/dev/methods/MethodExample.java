package com.dev.methods;

public class MethodExample {
public	static int j=0;
	static char ch='A';
	int area=0;
	
	
static	MethodExample me=new MethodExample();

	public static void main(String[] args) {

	int k=calArea(5);//we can call the static method by method name iside same class
	System.out.println(k);
		 j=calArea(4);//calling method by using object reference 
		System.out.println(j);
		 int area=calArea(4);
			System.out.println(area);
int area1=me.AresRec(3, 4);//call method by object reference
System.out.println("area of rectangle : "+area1);


	}
	public static int calArea(int side) { //it is a static member so no need to create objects using class name we can call the mehod
		
		int t= side*side;
		int n=me.AresRec(4, 8);
	//	System.out.println(n);
		
		return t;
		

	}
	public int AresRec(int length,int width) {  //non static method so we use object treference to call the method
		j= length*width;
		return j;
	}


}
