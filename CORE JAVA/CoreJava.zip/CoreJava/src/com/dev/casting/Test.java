package com.dev.casting;

//import java.awt.List;
//import java.util.ArrayList;
//import java.util.Scanner;
//
//public class Test {
//	public static void main(String[] args) {
//		int i=66;
//		byte b=(byte) i;
//		System.out.println(b);
//		char j=(char) i;
//		System.out.println(j);
//		int r=b;
//		short s=(short) i;
//		//List<String> li = new ArrayList<String>();
//		Scanner sc = new Scanner(System.in);
//		System.out.println("enter int");
//	 int k;
//	 k=sc.nextInt();
//	 System.out.println(k);
//	 
//	}
//
//}
class Test { 
    // static variable 
    static int a = 10; 
  
    // static block 
    static
    { 
        System.out.println("Inside static block"); 
    } 
  
    // static method 
    static int m1() 
    { 
        System.out.println("from m1"); 
        return 20; 
    } 
  
    // static method(main !!) 
    public static void main(String[] args) 
    { 
        System.out.println("Value of a : " + a); 
        System.out.println("from main"); 
    } 
;

} 
