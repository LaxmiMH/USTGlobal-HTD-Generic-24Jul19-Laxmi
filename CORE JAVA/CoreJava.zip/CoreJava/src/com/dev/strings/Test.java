package com.dev.strings;
import static com.dev.methods.Demo.*;

public class Test {
	public static void main(String[] args) {
		System.out.println(i);
		System.out.println(str);
		print();
	}

}
