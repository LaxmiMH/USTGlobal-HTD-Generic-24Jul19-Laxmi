package com.dev.strings;

public class StringMethods1 {
	public static void main(String[] args) {
		String str = "Hello_World";
		String str1="HELLO_WORLD";

		int length = str.length();
		System.out.println("output for length() : " +length);

		char[]	ch=str.toCharArray();
		System.out.println(ch);
		System.out.println("output for ltocharAth() : " +ch[5]);

		char c=str.charAt(4);
		System.out.println("output for charAT() : " +c);

		boolean b = str.equals(str1);
		System.out.println("output for equal() : " +b);

		boolean  b1=str.equalsIgnoreCase(str1); 

		System.out.println("output for equalignore()  : " +b1);

	}

}
