package com.dev.strings;

public class ReverseString {

	public static void main(String[] args) {
		String s="name is james";
		int l=s.length();
		for(int i=l-1;i>=0;i--) {
		//	s=s.charAt(i);
			System.out.print(s.charAt(i));
		}
		
		
//		System.out.println(s);
//		s=new StringBuffer(s).reverse().toString();
//		System.out.println(s);
	
		

	}

}
