package com.dev.strings;

public class StringMethods {
	public static void main(String[] args) {
		String str = "Some_string";
		String str1="some_stRiNg";

		int length = str.length();
		System.out.println("output for length() " +length);

		char[]	ch=str.toCharArray();
		System.out.println(ch);
		System.out.println("output for ltocharAth() " +ch[10]);

		char c=str.charAt(4);
		System.out.println("output for charAT() " +c);

		boolean b = str.equals(str1);
		System.out.println("output for equal() " +b);

		boolean  b1=str.equalsIgnoreCase(str1); 

		System.out.println("output for equalignore() " +b1);

		boolean v = str.contains("A");
		System.out.println("output for contains() " +v);
		
		boolean v1 = str.contains("Som");
		System.out.println("output for contains() " +v1);

		String g=str1.replace('s', 'A');
		System.out.println("output for replace() "+ g);
		
		int k = str.indexOf('s');
		System.out.println("output of index of(): "+k);
		
		String m=str.toUpperCase();
		System.out.println("output oftoUpperCase(): "+m);
		
		String j=m.toLowerCase();
		System.out.println("output oftoLowerCase(): "+j);
		
		String a=str.substring(3);
		System.out.println("output for substring():"+a);
		
		
		
String q=str.substring(3, 8);
		System.out.println("output for substring():"+q);
		
	}

}
