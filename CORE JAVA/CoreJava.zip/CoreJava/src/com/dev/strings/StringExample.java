package com.dev.strings;

public class StringExample {

	public static void main(String[] args) {
		
		String str="hello";
		System.out.println(str);
		
		String str1;
		str1="hello";
		System.out.println(str1);
		
		String str2=new String("hello"); // if both strings content is same then that both string have the same address
		System.out.println(str2);
		System.out.println(Integer.toHexString(str2.hashCode()));
		System.out.println(Integer.toHexString(str1.hashCode()));
		
		StringBuffer s= new StringBuffer("hello");
		System.out.println(s);

		StringBuilder s1=new StringBuilder("java");
		System.out.println(s1);
		
		System.out.println(s+" "+s1); //+ operator overloading it acts as addition + concatenation
//		StringBuffer s2= new StringBuffer(-1); //negetive size of string buffer is exception
//		System.out.println(s2);
		
		System.out.println(s.length());
		System.out.println(s.capacity());
		
		String e=new String("hii");
		e="kvkn";

	}

}
