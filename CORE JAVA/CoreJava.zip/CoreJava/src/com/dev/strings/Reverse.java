package com.dev.strings;



public class Reverse {

	public static void main(String[] args) {
		String s[]="name is james ".split( " " );
		String s1=" ";
		int l=s.length;
		System.out.println(s.length);
		for(int i=l-1;i>=0;i--) {
		//	s=s.charAt(i);
			s1+= s[i]+" ";
			
		}
		System.out.print(s1.substring(0, s1.length() -1));
		
		
//		System.out.println(s);
//		s=new StringBuffer(s).reverse().toString();
//		System.out.println(s);
	
		

	}

}

