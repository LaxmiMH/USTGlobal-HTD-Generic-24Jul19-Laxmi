package com.dev.lambdaexp;

public class FunInt {
public static void main(String[] args) {
	FunInter f = ()->{
		for(int i=1;i<=10;i++) {
			System.out.println("i=" +i);
		}
	}; //always close lambda expression with semi colon
	
	//if we have block of code to execute inside the functional interface we have to write that in {}
	FunInter f1=()->{
		try {
			int j=10/2;
			System.out.println("j is: "+j);
			int i=10/0;
			
			System.out.println(i);
			
		}catch(Exception e) {
			System.out.println("exception");
		}
	};
	//if we have only single line of code to execute then we will write that in single line
	FunInter f2 =()->System.out.println("functional interface");
	
	funInt2 f3=(int i)->{
		for(int j=1;j<=i;j++) {
			System.out.println(j);
		}
	};
	
	f.printVal();
	f1.printVal();
	f2.printVal();
	f3.printVal(5);

}
}
