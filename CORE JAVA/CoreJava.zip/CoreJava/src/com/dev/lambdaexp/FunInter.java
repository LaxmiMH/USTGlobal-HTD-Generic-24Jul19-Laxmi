package com.dev.lambdaexp;
@FunctionalInterface
public interface FunInter {
public void printVal();
}
