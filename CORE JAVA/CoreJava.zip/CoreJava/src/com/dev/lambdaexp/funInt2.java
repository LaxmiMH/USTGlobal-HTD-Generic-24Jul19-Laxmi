package com.dev.lambdaexp;

@FunctionalInterface
public interface funInt2 {
public void printVal(int i);
}
