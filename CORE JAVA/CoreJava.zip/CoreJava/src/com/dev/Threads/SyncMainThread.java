package com.dev.Threads;

public class SyncMainThread {

	public static void main(String[] args) throws InterruptedException {
		System.out.println("Sync main thread started...");
		Printer p = new Printer();//only one printer which access by 2 syatems same time
		
		Thread4 t4 = new Thread4(p);
		t4.start();
	t4.join(); //to display this 1st we use
		new Thread5(p).start();
		Printer p2 = new Printer();

		Thread4 t5 = new Thread4(p2);
		t5.start();
		
		
		
		System.out.println("Sync main thread terminated...");
	}

}
