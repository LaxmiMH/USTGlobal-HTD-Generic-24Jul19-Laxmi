package com.dev.Threads;

// by extends thread class we create the our own thread
public class Thread2 extends Thread {
	
	//run and start method also works for thread
@Override
public void run() {
System.out.println("T2 thread started...");
for(int j=1;j<=10;j++) {
	System.out.println("j= "+j);
}

System.out.println("T2 thread teminated");
}
}
