package com.dev.Threads;

public class MainThreadClass {
public static void main(String[] args) {
	//only one thread running i.e main thread
	System.out.println("main thread started...");
	Thread2 t4=new Thread2();
	t4.setName("Thread T2");
	t4.start();
	t4.setPriority(2);

	
//new T2().start(); //by creating the objevct we call the syart method
	//new Thread2().run(); 
//new Thread3().run();
Thread3 t3=new Thread3();
Thread t=new Thread(t3);
t.start();
//to set name for main thread
Thread.currentThread().setName(" main Thread ");
//new Thread(new T3()).start();
	
	for(int i=1;i<=10;i++) {
		System.out.println("i= "+i);
	}
	System.out.println("Thread name: "+t4.getName());
	System.out.println("main thread name: "+Thread.currentThread().getName());
	System.out.println("thread2 id"+t4.getId());
	System.out.println("thread id"+t.getId());
	System.out.println("priority of the thread: "+t4.getPriority());
	
	System.out.println("Mian thread terminated...");
}
}
