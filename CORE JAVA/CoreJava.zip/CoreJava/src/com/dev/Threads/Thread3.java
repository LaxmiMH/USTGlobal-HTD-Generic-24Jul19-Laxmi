package com.dev.Threads;

public class Thread3 implements Runnable {

	// runnable not have start method so only run works
	@Override
	public void run() {
		System.out.println("T3 thread started...");
		for(int k=1;k<=10;k++) {
			System.out.println("k= "+k);
		}

		System.out.println("T3 thread teminated");
	}

}
