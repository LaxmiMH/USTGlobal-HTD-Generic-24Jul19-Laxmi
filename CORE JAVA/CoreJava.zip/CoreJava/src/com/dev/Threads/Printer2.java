package com.dev.Threads;

public class Printer2 {
 	public void printVal(int i,String thread) {
		for(int j=0;j<=i;j++) {
			System.out.println("thread: "+thread+" "+"j ="+j);
		}

	}

}
