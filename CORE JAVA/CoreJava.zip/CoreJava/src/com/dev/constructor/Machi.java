package com.dev.constructor;

import com.dev.abstraction.Macha;

public class Machi {


	public static void main(String[] args) {
		int u=	Macha.i;
		String s=Macha.str;
		Macha.show();
		System.out.println(u);
		System.out.println(s);

	}

}
