package com.dev.constructor;

import com.dev.methods.MethodExample;

public class Demo {
	public static void main(String[] args) {
		int i= MethodExample.calArea(3);
		System.out.println(i);
		System.out.println(MethodExample.j);
	}
	
	

}
