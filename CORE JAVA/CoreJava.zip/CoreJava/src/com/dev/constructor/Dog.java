package com.dev.constructor;

public class Dog {

}
