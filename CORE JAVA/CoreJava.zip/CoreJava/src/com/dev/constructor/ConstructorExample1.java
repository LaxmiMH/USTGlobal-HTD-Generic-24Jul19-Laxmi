package com.dev.constructor;

public class ConstructorExample1 {
	public ConstructorExample1() {
		System.out.println("this is no argument constroctor");
	}
	public ConstructorExample1(int k) {
		System.out.println("this is eithsrgument constr");
	}
	public  ConstructorExample1(boolean b,String m) {
		System.out.println("this is boolean and string argument constroctor");
	}
	public ConstructorExample1(String b,boolean m) {
		System.out.println("this is string and  boolean argument constroctor"+b+ " "+m);
	}
	public ConstructorExample1(boolean b,String m,int i) {
		System.out.println("this is boolean and string AND int argument constroctor");
	}

	public static void main(String[] args) {

		ConstructorExample1 ce=new ConstructorExample1();
		System.out.println(ce);
		ConstructorExample1 ce1=new ConstructorExample1(3);
		System.out.println(ce1);
		ConstructorExample1 ce2=new ConstructorExample1(true," k");
		System.out.println(ce2);
		ConstructorExample1 ce3=new ConstructorExample1(true," k",6);
		System.out.println(ce3);
		ConstructorExample1 ce4=new ConstructorExample1(" k",false);
		System.out.println(ce4);

	}

}
