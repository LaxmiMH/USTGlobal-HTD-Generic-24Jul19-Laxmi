package com.dev.constructor;

public class ConstructorExample {
public ConstructorExample(int i) { //this constr is created by us
	System.out.println("this is const with arg");
}
public ConstructorExample() { //this constr is creaby usted with no arg
	System.out.println("this is const with no arg");
}

public ConstructorExample(String s) {
	System.out.println("this is const with String arg");
	
}
public ConstructorExample(String s,int i) {
	System.out.println("this is string and int constructor");
}
public ConstructorExample(int i,String s) {
	System.out.println("this is int and string constructor");
}
	public static void main(String[] args) {
		ConstructorExample c= new ConstructorExample(1);
		ConstructorExample c1= new ConstructorExample();
		ConstructorExample c2= new ConstructorExample(" ");
		ConstructorExample c3= new ConstructorExample("A",3);
		ConstructorExample c4= new ConstructorExample(3,"A");
		
	
	}

}
