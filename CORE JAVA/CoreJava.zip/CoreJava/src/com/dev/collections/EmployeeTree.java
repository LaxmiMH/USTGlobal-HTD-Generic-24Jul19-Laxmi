package com.dev.collections;

import java.util.TreeSet;


public class EmployeeTree {
	public static void main(String[] args) {
		TreeSet<Employee> te=new TreeSet<Employee>();
		
		Employee e= new Employee();
		e.setId(1);
		e.setName("shreeram");
		e.setEmail("shreeram@gmail.com");
		e.setPassword(123);
		
		Employee e1= new Employee();
		e1.setId(4);
		e1.setName("suman");
		e1.setEmail("suman@gmail.com");
		e1.setPassword(125464);
		
		Employee e2= new Employee();
		e2.setId(3);
		e2.setName("shravya");
		e2.setEmail("shravya@gmail.com");
		e2.setPassword(12);
		
		te.add(e);
		te.add(e1);
		te.add(e2);
		System.out.println(te);
		
	}

}
