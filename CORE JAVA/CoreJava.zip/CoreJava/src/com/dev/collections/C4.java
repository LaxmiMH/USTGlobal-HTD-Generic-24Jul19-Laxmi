package com.dev.collections;

import com.dev.encapsulation.Dog;
import java.util.ArrayList;
public class C4 {

	public static void main(String[] args) {
		ArrayList<Dog> arr1=new ArrayList<Dog>();
		
		Dog d= new Dog();
		d.setAge(1);
		d.setBreed("D M");
		d.setName("shiro");
		d.setColor("black");
		
		Dog d1= new Dog();
		d1.setAge(6);
		d1.setBreed("Dalmation");
		d1.setName("raja");
		d1.setColor("brown");
		

		Dog d2= new Dog();
		d2.setAge(5);
		d2.setBreed("Dalmation");
		d2.setName("rani");
		d2.setColor("black&white");
		
		arr1.add(d);
		arr1.add(d1);
		arr1.add(d2);
		System.out.println(arr1);
	arr1.trimToSize();	
		System.out.println("after tim"+arr1.size());

	}

}
