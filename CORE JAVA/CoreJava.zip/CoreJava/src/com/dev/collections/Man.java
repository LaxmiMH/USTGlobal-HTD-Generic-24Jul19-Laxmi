package com.dev.collections;

public class Man {

}
