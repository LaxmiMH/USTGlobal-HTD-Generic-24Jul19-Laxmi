package com.dev.collections;

import java.util.HashMap;



public class Eimpl implements E {
	HashMap<String,Employee1> hm = new HashMap<String,Employee1>();

	@Override
	public Employee1 addEmployee(String k, Employee1 e) {
		if(e != null) {
			hm.put(k, e);
			Employee1 b = hm.put(k,e);
			if(b!=null) {
				return e;
			}
		}
		return null;
	}


}
