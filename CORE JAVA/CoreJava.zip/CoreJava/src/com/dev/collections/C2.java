package com.dev.collections;

import java.util.HashMap;

import com.dev.encapsulation.Dog;

public class C2  {
	public static void main(String[] args) {
		HashMap<String,Dog> hm = new HashMap<String,Dog>();
		Dog d= new Dog();
		d.setAge(1);
		d.setBreed("D M");
		d.setName("shiro");
		d.setColor("black");
		
		Dog d1= new Dog();
		d1.setAge(2);
		d1.setBreed("Dalmation");
		d1.setName("raja");
		d1.setColor("brown");
		

		Dog d2= new Dog();
		d2.setAge(2);
		d2.setBreed("Dalmation");
		d2.setName("rani");
		d2.setColor("black&white");
		
		d.setAge(2);
		d1.setAge(3);
		d2.setAge(5);
		hm.put("1", d);
		hm.put("2", d1);
		hm.put("3", d2);
//		for(Dog dog:hm) {
//			
//		}
	//	hm.put("1", null); //return type is null
		 Dog b=hm.put("1", d);//we used this again put for d so it reurns that object
			Dog b1=hm.put("2", d1);
			Dog b2=hm.put("3", d2);
			System.out.println(b);
		System.out.println(hm);
		 Dog f= hm.remove("2");
		 System.out.println(f);
		 System.out.println(hm);
		
		 
		 System.out.println("output of conatinsKey(): "+hm.containsKey("1"));
		 System.out.println("output of conatinsValue(): "+hm.containsValue(d2));
System.out.println(hm.size());
		
	}

}
