package com.dev.collections;

public class D {
public static void main(String[] args) {
	HashSet<Man> hs=new HashSet<Man>
}
}
