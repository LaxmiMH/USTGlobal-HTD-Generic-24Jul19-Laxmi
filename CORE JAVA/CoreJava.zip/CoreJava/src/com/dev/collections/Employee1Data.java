package com.dev.collections;

public class Employee1Data {
	public static void main(String[] args) {
		Eimpl em=new Eimpl();
		Employee1 e=new Employee1();
		e.setName("shree");
		e.setAge(1);
		Employee1 e1=new Employee1();
		e1.setName("shreedevi");
		e1.setAge(2);
		
		Employee1 b=em.addEmployee("1",e);
		Employee1 b1=em.addEmployee("2",e1);
		System.out.println(b+" "+b1);
	}
	

}
