package com.dev.collections;





public interface E  {
 public Employee1 addEmployee(String k,Employee1 e);
 //public 
}
