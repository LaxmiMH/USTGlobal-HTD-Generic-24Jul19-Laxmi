package com.dev.collections;

import java.util.HashSet;

public class EmployeeHash {
	public static void main(String[] args) {
		HashSet<Employee> hs= new HashSet<Employee>();
		
		Employee e= new Employee();
		e.setId(1);
		e.setName("shreeram");
		e.setEmail("shreeram@gmail.com");
		e.setPassword(123);
		Employee e1= new Employee();
		e1.setId(2);
		e1.setName("suman");
		e1.setEmail("suman@gmail.com");
		e1.setPassword(125464);
		
		Employee e2= new Employee();
		e2.setId(3);
		e2.setName("shravya");
		e2.setEmail("shravya@gmail.com");
		e2.setPassword(12);
		//create collection using hashset
		 boolean b=hs.add(e);
		 boolean b1=hs.add(e1);
		 boolean b2=hs.add(e2);
		System.out.println("output of add(): "+b+" "+b1+" "+b2);
		System.out.println(hs);
		
		//update
		e1.setEmail("sakshara@gmail.com");
		e2.setEmail("sonu@gmail.com");
		System.out.println(hs);
		

		
		
	}

}
