package com.dev.inheritance;


public class Child4 extends Parent1 {

	public static void main(String[] args) {
		
Child4 c=new Child4();
c.PrintName();
//Parent1.PrintName(); by using . operator we can access
	}
@	Override
	public void PrintName() {
		System.out.println("child method");
	super.PrintName();
}

}
