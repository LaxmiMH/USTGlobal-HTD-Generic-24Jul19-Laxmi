package com.dev.inheritance;

public class Child extends Father {
	static Child c=new Child();
	@Override
	public void printName() {
		String name = "Laxmi";
	System.out.println(name+" "+super.name+" "+c.lastname);
	System.out.println(name+" "+c.name+" "+c.lastname);
		
	}

	public static void main(String[] args) {
		c.printName();
	}
}
