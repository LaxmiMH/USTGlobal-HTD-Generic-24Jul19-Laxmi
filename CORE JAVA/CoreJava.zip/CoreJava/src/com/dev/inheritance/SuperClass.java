package com.dev.inheritance;

public class SuperClass {
	public SuperClass() {
		System.out.println("const with no arg of super class");
	}
	public SuperClass(int i) {
		System.out.println("const with int arg of super class");
	}
	public SuperClass(String str) {
		System.out.println("const with String arg of super class");
	}
	public SuperClass(String str,int i) {
		System.out.println("const with string and int arg of super class");
	}
	public SuperClass(int i,String str) {
		System.out.println("const with int and string arg of super class");
	}




	public static void main(String[] args) {
	
		SubClass s=new SubClass();

	}

}
