package com.dev.inheritance;

public class Parent1 {
	public static void main(String[] args) {
		Parent1 p= new Parent1();
		p.PrintName();
		
	}
	
	
public  void  PrintName() {
	System.out.println("parent method");
	
}

}
