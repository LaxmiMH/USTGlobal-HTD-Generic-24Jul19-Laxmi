package com.dev.inheritance;

public class MySubClass extends MySuperClass {
	public MySubClass() {
	System.out.println("subclass called");
	}

	public static void main(String[] args) {
		MySubClass m1=new MySubClass();
//		MySuperClass c=new MySuperClass();

	}

}
