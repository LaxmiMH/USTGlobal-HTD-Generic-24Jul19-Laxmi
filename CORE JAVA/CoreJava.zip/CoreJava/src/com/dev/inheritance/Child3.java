package com.dev.inheritance;

public class Child3 extends Parent {
	static Child3 ch=new Child3();
	static  String name="jaya";
	public void ParentName() {
		System.out.println(name+ " "+super.name+" "+super.lastname);
	}
	public static void main(String[] args) {
		ch.ParentName();
		
	}
	

}
