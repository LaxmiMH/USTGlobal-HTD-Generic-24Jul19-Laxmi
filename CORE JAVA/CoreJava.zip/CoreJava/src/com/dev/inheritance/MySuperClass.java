package com.dev.inheritance;

public class MySuperClass {
	
	public MySuperClass() {
		System.out.println(" super class called");
	}

	public static void main(String[] args) {
		
MySubClass m=new MySubClass();

	}

}
