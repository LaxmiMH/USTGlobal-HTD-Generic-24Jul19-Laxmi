package com.dev.inheritance;

public class Child1 extends Father {
	static Child1 c1=new Child1();
	@Override
	public void printName() {
		String name = "Shreeram";
		System.out.println(name+" "+super.name+" "+c1.lastname);
		super.printName();
	}

	public static void main(String[] args) {
		c1.printName();
	}
}


