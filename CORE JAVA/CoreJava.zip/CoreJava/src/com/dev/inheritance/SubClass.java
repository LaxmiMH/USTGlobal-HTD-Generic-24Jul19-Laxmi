package com.dev.inheritance;

public class SubClass extends SuperClass {
	public SubClass() {
	super(1);  //without super also the compiler call the super class const
	}
	public static void main(String[] args) {
		SubClass s=new SubClass();
		
	}

}
