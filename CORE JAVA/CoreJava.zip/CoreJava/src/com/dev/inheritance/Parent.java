package com.dev.inheritance;

public class Parent {
static 	String name="kasturi";
static	String lastname="hirabayi";
static Parent p=new Parent(); 
	
public void  ParentName() {
		System.out.println(name+ " "+p.lastname);
	}

public static void main(String[] args) {
	p.ParentName();
		
	}
}
