package com.dev.inheritance;

public class GrandFather {
	 static GrandFather g = new GrandFather();
	 static String lastname ="Hirabayi";
	static String name ="Fakkirappa";
		 
	
	public static void main(String[] args) {
	g.printName();
		
	}
	
	public void printName() {
		
		System.out.println(name+ " "+g.lastname);
	}

}
