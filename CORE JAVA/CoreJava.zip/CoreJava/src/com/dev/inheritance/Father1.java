package com.dev.inheritance;

public class Father1 {
	
	static  String lastname="Hirabayi";
	static String Name="Maruti";
	static Father1 f=new Father1();
	public static void main(String[] args) {
	
	}
	public void firsName() {
		System.out.println(Name+ " "+f.lastname);
		
	}

}
