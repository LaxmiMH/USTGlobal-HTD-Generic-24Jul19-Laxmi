package com.dev.exceptions;

public class ExceptionHandling1 extends CustomException {
	public static void main(String[] args) throws CustomException { //it can thow exception i.enagative arrysize
		//it tell that the s and main will throw the exception but it is not handle
		
//	s(); //might or might not be throw exceprtion
//		
//		System.out.println("code after the exception");
		try {
			//divide(10,0);
			s();
			System.out.println("no exception for s()");
			int res=divide(10,0);
			System.out.println("no exception for divide()");
			System.out.println(res);
	} catch (NegativeArraySizeException e) {
		//throw new  CustomException();
		//by using throw we can call our own handler
			System.out.println("exception caught in catch block");
		System.out.println("get message"+ e.getMessage());
		e.printStackTrace();
		}
	catch (ArithmeticException e) {
			//throw new  CustomException();
			//by using throw we can call our own handler
				System.out.println(" divideexception caught in catch block");
			System.out.println("get message"+ e.getMessage());
			e.printStackTrace();
			}
		catch (Exception e) {
			//throw new  CustomException();
			//by using throw we can call our own handler
				System.out.println("exception ");
		System.out.println("get message"+ e.getMessage());
			e.printStackTrace();
			}

		finally {
				System.out.println("finally block");
			}
	}
	
public static int divide(int i,int j) {  
		int res = i/j;
		System.out.println(res);
		return 1;
	
}
	public static void s() {  
//	try {
//			StringBuffer s=new StringBuffer(-1);
//		} catch (Exception e) {
//		//	new CustomException().printStackTrace();
//		System.out.println("getlocalize"+e.getLocalizedMessage());
//			
//		}
		StringBuffer s=new StringBuffer(1);
	
	
}
}
