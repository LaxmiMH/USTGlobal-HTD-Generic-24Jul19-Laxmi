package com.dev.exceptions;

public class CustomException extends Exception {
	public CustomException() {
		System.out.println("custom exception");
	}
	public CustomException(int i) {
		System.out.println(" int custom exception");
	}
	public CustomException(String s) {
		System.out.println(" string custom exception");
	}

//	public String getMessage() {
//		return " ";
//	}
	@Override
 public String getLocalizedMessage() {
	// System.out.println(" get message blockkkkk");
	 return "custom exception message";
 }
}
