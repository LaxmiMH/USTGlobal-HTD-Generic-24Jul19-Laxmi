package com.dev.exceptions;

public class ExceptionHandling2 extends CustomException {
	public static void main(String[] args) throws CustomException {
		s();
		throw new CustomException();
		

}
	public static void s() throws CustomException{
		int i = -1;
		try {
			StringBuffer s=new StringBuffer(i);
			if(i<0) {
				System.out.println("there is  exception");
			}
		} catch (Exception e) {
			System.out.println("get message: "+e.getMessage());//it refer to throwable class
			System.out.println(new CustomException().getMessage());//refer to our exception
			System.out.println(new CustomException().getLocalizedMessage());//refer to our exception
			System.out.println(e.getLocalizedMessage());//refer to throwable class and which will return the throwable getmessage
		}
	}
}
