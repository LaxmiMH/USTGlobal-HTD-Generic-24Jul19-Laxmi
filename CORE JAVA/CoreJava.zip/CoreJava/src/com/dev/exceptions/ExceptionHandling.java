package com.dev.exceptions;

public class ExceptionHandling {
	public static void main(String[] args) {
		try {
			s(); //exception occur in this method
		}catch(Exception e) {
			System.out.println("exception occured");
			e.printStackTrace();//gives information about exception
			
		}finally {
			System.out.println("this is finally bock");
		}
		System.out.println("code after execution");
		StringBuffer s1=new StringBuffer("hello");
		StringBuffer s2= new StringBuffer("hello");
		System.out.println(Integer.toHexString(s2.hashCode()));
		s2=s1.replace(1, 3, "mm");
		System.out.println(s2);
		System.out.println(Integer.toHexString(s2.hashCode()));
		String s3="hello";
		
		
		
	}
	public static void s() {  
		StringBuffer s=new StringBuffer(-1);
	}
}
