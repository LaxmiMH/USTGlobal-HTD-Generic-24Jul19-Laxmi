package com.dev.exceptions;

public class ExceptionExample {

	public static void main(String[] args) {
		double d=10.0;
		double q=0.0;
		System.out.println("result: "+d/q);
		System.out.println("print before exception");
	//	StringBuffer s=new StringBuffer(-1);
	//	System.out.println(s);  //exception negativearray size at runtime not compile time
		//program will stop here bcz of exception
		t();   //caller method
		//s();
		System.out.println("print after exception");
	}
	public static void s() {  //called method
		StringBuffer s=new StringBuffer(-1);
	}
	public static void t() {
		s();
	}

}
