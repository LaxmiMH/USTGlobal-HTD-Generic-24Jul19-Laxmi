package com.dev.abstraction;

public class E implements Abs  {
	public static void main(String[] args) {
		
		E e =new E();
		e.display();
		Abs.print();
	}

	@Override
	public void display() {
		System.out.println(" display method interface");
		
	}

}
