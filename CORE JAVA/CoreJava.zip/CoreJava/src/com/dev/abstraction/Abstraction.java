package com.dev.abstraction;

public  class Abstraction extends AbstractExample {

	// AbstractExample ae=new AbstractExample(); not able to create object for abstract clas
	public Abstraction() {
		System.out.println("construtor of Abstraction class");
	}

	@Override
	void display() {
		System.out.println("this is the implemented abstract method ");

	}
	static void display1() {
		System.out.println("this is the abstraction method ");

	}
	public static void main(String[] args) {
		Abstraction a=new Abstraction();
		a.display();
		a.show();
		display1();
	//	AbstractExample ae=new AbstractExample();	
	}


	

}
