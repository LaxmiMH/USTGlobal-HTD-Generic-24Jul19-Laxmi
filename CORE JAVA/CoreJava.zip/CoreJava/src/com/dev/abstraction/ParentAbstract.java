package com.dev.abstraction;

public abstract class  ParentAbstract {
	abstract void parent();
	abstract void print();

	public void child() {
		System.out.println("this concrete method");
	}
	public static void main(String[] args) {
		

	}

}
