package com.dev.abstraction;

public abstract class AbstractExample {
	abstract void display() ;//abstract method is there so class need to be declare as abstract
 // abstract void print();
	
	public AbstractExample() {
		System.out.println("constuctor of Abstract class ");
	}

	public static void show() {
		System.out.println("concrete method of abstrct class");

	}
	public static void main(String[] args) {
		AbstractExample.show();		
	}

	

}
