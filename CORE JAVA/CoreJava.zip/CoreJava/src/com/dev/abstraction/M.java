package com.dev.abstraction;

public interface M  extends Abs{

}
