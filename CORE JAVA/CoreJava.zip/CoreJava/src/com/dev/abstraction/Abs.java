package com.dev.abstraction;

@FunctionalInterface
public interface Abs extends Cloneable{
	void display();

	final int i=2; //it should initilize at the time of declaration it should be final,static or public
	static void print() {
		System.out.println(" hii");
	}
	static void print1() {
		System.out.println(" hii");
	}


}
