package com.dev.abstraction;

public interface N  extends Abs{

}
