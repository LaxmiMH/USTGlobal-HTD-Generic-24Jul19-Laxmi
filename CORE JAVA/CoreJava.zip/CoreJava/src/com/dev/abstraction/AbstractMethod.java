package com.dev.abstraction;

public abstract class AbstractMethod extends ParentAbstract{

	@Override
	void parent() {
		System.out.println("this is concrete child method");
		
	}
	public static void main(String[] args) {
		
	}

}