
package com.dev.abstraction;

public class ConcreteChild extends ParentAbstract {

	
	
	public static void main(String[] args) {
		
		ConcreteChild c= new ConcreteChild();
		c.child();
		
	}

	@Override
	void parent() {
		// TODO Auto-generated method stub
		
	}

	@Override
	void print() {
		// TODO Auto-generated method stub
		
	}
	
}
