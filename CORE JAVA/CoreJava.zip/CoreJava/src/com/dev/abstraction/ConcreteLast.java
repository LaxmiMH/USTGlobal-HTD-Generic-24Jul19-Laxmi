package com.dev.abstraction;

public class ConcreteLast extends AbstractMethod {

	public static void main(String[] args) {
		
		ConcreteLast c=new ConcreteLast();
		c.child();
		c.parent();
	}

	@Override
	void print() {
		System.out.println("this is print method");
		
	}
	@Override
	void parent() {
		System.out.println("this is parent");
		
	}
}
