package com.dev.abstraction;

public interface Abs1 {

	void display1();
  final  int i=2;
	static void print() {
		System.out.println(" hii");
	}

}
