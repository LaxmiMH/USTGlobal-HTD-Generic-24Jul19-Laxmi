package com.dev.abstraction;

public class Macha {

	public	 static int i=2;
	public static String str="ABC";

	public static void show() {
		System.out.println("show() ");
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
