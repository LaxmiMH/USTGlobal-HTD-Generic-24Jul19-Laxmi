package com.dev.encapsulation;

public class pets {
	private String dogname;
	private String rabbitname;
	private String parrotname;
	public String getDogname() {
		return dogname;
	}
	public void setDogname(String dogname) {
		this.dogname = dogname;
	}
	public String getRabbitname() {
		return rabbitname;
	}
	public void setRabbitname(String rabbitname) {
		this.rabbitname = rabbitname;
	}
	public String getParrotname() {
		return parrotname;
	}
	public void setParrotname(String parrotname) {
		this.parrotname = parrotname;
	}

}
