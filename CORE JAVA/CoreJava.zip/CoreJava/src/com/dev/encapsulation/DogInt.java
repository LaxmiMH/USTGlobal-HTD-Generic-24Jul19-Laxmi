package com.dev.encapsulation;

public interface DogInt {
public boolean addDog(Dog dog);
public void getDog();
public boolean removeDog(Dog dog);
}
