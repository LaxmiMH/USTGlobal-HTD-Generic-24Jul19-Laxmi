package com.dev.encapsulation;

public class StudentData {

	public static void main(String[] args) {
		Student s= new Student();
		s.setRegno(20190001);
		s.setName("laxmi");
		s.setEmail("laxmi@email.com");
		s.setPassword("1234");
		
 System.out.println("Regno : "+s.getRegno());
		System.out.println("Name : "+s.getName());
		System.out.println("email : "+s.getEmail());
		System.out.println("**************");

	}
	
	

}
