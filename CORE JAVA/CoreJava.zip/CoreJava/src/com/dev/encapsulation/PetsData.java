package com.dev.encapsulation;

public class PetsData {

	public static void main(String[] args) {
		pets p1=new pets();
		pets p2=new pets();
		p1.setDogname("robby");
		p1.setParrotname("sonu");
		p1.setRabbitname("bobby");
		
		p2.setDogname("raja");
		p2.setParrotname("monu");
		p2.setRabbitname("lobby");
		
		pets [ ] pet= {p1,p2};
		for(int i=0;i<pet.length;i++) {
			System.out.println("dog name :"+pet[i].getDogname());
			System.out.println("rabbit name : "+pet[i].getRabbitname());
			System.out.println("parrot name : "+pet[i].getParrotname());
			System.out.println("****************");
		}
	}

}
