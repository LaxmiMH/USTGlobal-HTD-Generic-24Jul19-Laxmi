package com.dev.encapsulation;

public class DogData1 {
	public static void main(String[] args) {
		DogImpl dii = new DogImpl();
		Dog d = new Dog();
		d.setAge(1);
		d.setBreed(" g s");
		d.setColor("blue");
		d.setName("agg");
		d.setGender("female");
		
		Dog d1 = new Dog();
		d1.setAge(2);
		d1.setBreed(" g s");
		d1.setColor("blue");
		d1.setName("agg");
		d1.setGender("male");
		boolean b=dii.addDog(d);
		boolean b1=dii.addDog(d1);
		System.out.println(b+" "+b1);
		
		dii.getDog();
		
	boolean f=	dii.removeDog(d);
	System.out.println(f);
	dii.getDog();;
	}
	
	

}
