package com.dev.polymorphism;

public class CompileTime {
	public void comiple() {
		System.out.println("compile method with no args");
	}
	public int comiple(int i) {
		System.out.println("compile method with int args"+ i);
		return 1;
	}


	public static void main(String[] args) {
		
		CompileTime c=new CompileTime();
		c.comiple();
		c.comiple(3);

	}

}
