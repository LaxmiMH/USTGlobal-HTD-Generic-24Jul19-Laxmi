package com.dev.polymorphism;

public class RunTime1 extends RunTime {
	static RunTime1 m= new RunTime1();
	@Override
public void rmethod() {
	super.rmethod();
	
}
	public static void main(String[] args) {
	
		m.rmethod();
	
		
	}

}
