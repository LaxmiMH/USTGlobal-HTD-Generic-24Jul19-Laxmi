package com.dev.polymorphism;

public class RunTime {
	static RunTime r=new RunTime();
	public void rmethod() {
		System.out.println("runtime method");
	}

	public static void main(String[] args) {
		r.rmethod();

	}

}
