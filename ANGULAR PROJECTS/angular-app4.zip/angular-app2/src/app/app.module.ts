import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CarsComponent } from './cars/cars.component';
import { RecipiesComponent } from './recipies/recipies.component';
import { NewsComponent } from './news/news.component';
import { MobilesComponent } from './mobiles/mobiles.component';
import { CarsDetailsComponent } from './cars-details/cars-details.component';
import { MobilesDetailsComponent } from './mobiles-details/mobiles-details.component';
import { NewsDetailsComponent } from './news-details/news-details.component';
import { RecipiesDetailsComponent } from './recipies-details/recipies-details.component';
import { HeaderComponent } from './header/header.component';

@NgModule({
  declarations: [
    AppComponent,
    CarsComponent,
    RecipiesComponent,
    NewsComponent,
    MobilesComponent,
    CarsDetailsComponent,
    MobilesDetailsComponent,
    NewsDetailsComponent,
    RecipiesDetailsComponent,
    HeaderComponent
  ],
  imports: [
    BrowserModule,
    // AppRoutingModule
    RouterModule.forRoot([
      { path: 'car',component: CarsComponent },
     { path: 'news',component:NewsComponent}, 
       { path: 'recipies',component:RecipiesComponent},
     { path: 'mobile',component:MobilesComponent},
    //  { path:'**', component:PageNotFoundComponent}

   ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
