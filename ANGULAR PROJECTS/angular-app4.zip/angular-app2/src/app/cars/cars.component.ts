import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cars',
  templateUrl: './cars.component.html',
  styleUrls: ['./cars.component.css']
})
export class CarsComponent implements OnInit {
  carData: any='';
  cars=[
    {
     brand:'Benz',
      img:'https://image.shutterstock.com/image-photo/mercedes-benz-600w-486541498.jpg',
      description:'Mercedes-Benz offers 19 car models in India, including 7 new car models in SUV/MUV category, 6 in Sedan category, 3 in Convertible category, 1 in Station Wagon category, 2 in Coupe category.Mercedes-Benz car price starts at Rs 31.72 Lakhs, the top line model costs Rs 2.33 Crore'
    },
    {
      brand:'audi',
      img:'https://image.shutterstock.com/image-photo/car-traveling-nature-on-asphalt-260nw-1404544163.jpg',
      description:'Audi launched the A4 last year with much fan-fare. At that time, it only came in a petrol variant, but now they have also introduced a diesel variant and these are our first impressions of the new variant. '
    },
    {
      brand:'Ford',
      img:'https://cdn.pixabay.com/photo/2017/05/24/06/53/ford-mustang-2339698__340.jpg',
      description:'Ford has currently 6 car models on sale, get a complete price list of Ford cars, read ... The Ford EcoSport, Ford Endeavour, Ford Figo are amongst the most popular cars.',
    },
    {
      brand:'Toyota',
      img:'https://image.shutterstock.com/image-photo/car-traveling-nature-on-asphalt-260nw-1404544163.jpg',
      description:'Pricelist, Check all the latest ex showroom prices of the Toyota cars from all over India,glanza, innova, fortuner, etios, etios liva, etios cross, corolla altis, camry'
    },
    {
      brand:'lamborghini',
      img:'https://cdn.pixabay.com/photo/2012/04/12/23/48/car-30990__340.png',
      description:'Lamborghini Cars India offers 3 Models in price range of Rs.2.99 crore to Rs. 3.97 ... Lamborghini Huracan EVO ... The ARAI claimed mileage of Lamborghini Urus petrol is 8.0 km/l and it would take around 16 litres of fuel to go the distance'
    },
    {
      brand:'Ferrari',
      img:'https://cdn.pixabay.com/photo/2017/11/09/01/49/ferrari-458-spider-2932191_960_720.jpg',
      description:'Ferrari Cars India offers 4 Models in price range of Rs.3.50 crore to Rs. 5.20 ... Ferrari cars price starts at Rs. 3.50 crore for the cheapest car Portofino and goes up to Rs. 5.20 crore for the top model Ferrari 812 Superfast. ... Ferrari 488 question'
    },
    {
      brand:'jaguar',
      img:'https://cdn.pixabay.com/photo/2016/10/11/07/54/car-1730778__340.jpg',
      description:'Jaguar car prices start(GST Included) at Rs 40.61 Lakh for the most inexpensive model in its lineup, the XE. ... The Jaguar XJ, Jaguar XF, Jaguar XE are amongst the most popular cars in their respective segments. Upcoming Jaguar cars in India include the XE 2019, E Pace, I-Pace.'
    },
    {
      brand:'Opel',
      img:'https://cdn.pixabay.com/photo/2017/04/06/15/53/oldtimer-2208636__340.png',
      description:'OPEL WORLDWIDE .... Opel will use reasonable efforts to ensure that the contents of this Site are accurate and up to date but does not accept any liability for .'
    },
    {
      brand:'KTM',
      img:'https://cdn.pixabay.com/photo/2014/06/29/12/58/racing-car-379386__340.jpg',
      description:'The KTM X-Bow (pronounced crossbow) is an ultra-light sports car for road and race use, produced by Austrian motorcycle manufacturer KTM. It represented the first car in their product range and was launched at the Geneva Motor Show in 2008.'
    },
    {
      brand:'Mercury',
      img:'https://cdn.pixabay.com/photo/2016/09/19/22/10/mercury-1681443__340.jpg',
      description:'Mercury (automobile) ... Mercury is a defunct division of the U.S. automobile manufacturer Ford Motor Company. Marketed as an entry-level premium brand for nearly its entire existence, Mercury was created in 1938 by Edsel Ford to bridge the price gap between the Ford and Lincoln vehicle lines'
    },
  ]

  constructor() { }
  sendCar(car){
    this.carData=car;
  }

  ngOnInit() {
  }

}
