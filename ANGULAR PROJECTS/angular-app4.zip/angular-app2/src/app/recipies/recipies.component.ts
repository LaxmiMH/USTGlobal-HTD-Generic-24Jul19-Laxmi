import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recipies',
  templateUrl: './recipies.component.html',
  styleUrls: ['./recipies.component.css']
})
export class RecipiesComponent implements OnInit {
  recipiesData: any='';
  recipies=[
    {
     name:'idli',
      img:'https://cdn.pixabay.com/photo/2014/06/18/16/32/idli-371417__340.jpg',
      description: 'Idli or idly are a type of savoury rice cake, originating from the Indian subcontinent, popular as breakfast foods in southern India and among Indian-origin Tamils in Sri Lanka. The cakes are made by steaming a batter consisting of fermented black lentils and rice'
    },
    {
      name:'Dosa',
      img:'https://media-public.canva.com/MACNAaC4iaA/1/thumbnail_large.jpg',
      description:'A dosa is a cooked flat thin layered rice batter, originating from the Indian subcontinent, made from a fermented batter. It is somewhat similar to a crepe in appearance. Its main ingredients are rice and black gram ground together in a fine, smooth batter with a dash of salt.'
    },
    {
      name:'Biriyani',
      img:'https://image.shutterstock.com/image-photo/hyderabadi-biryani-form-hyderabad-india-260nw-562943647.jpg',
      description:'Biryani, also known as biriyani, biriani, birani or briyani, is a mixed rice dish with its origins among the Muslims of the Indian subcontinent. It can be compared to mixing a curry, later combining it with semi-cooked rice separately.'
    },
      {
        name:'pizza',
      img:'https://image.shutterstock.com/image-photo/pepperoni-pizza-on-wooden-board-260nw-562149826.jpg',
      description:'Pizza is a savory dish of Italian origin, consisting of a usually round, flattened base of leavened wheat-based dough topped with tomatoes, cheese, and various other ingredients baked at a high temperature, traditionally in a wood-fired oven'
    },
    {
      name:'pasta',
      img:'https://image.shutterstock.com/image-photo/pasta-spicy-tomato-sauce-parmesan-260nw-1007815945.jpg',
      description:'Pasta is a type of food typically made from an unleavened dough of durum wheat flour mixed with water or eggs, and formed into sheets or various shapes, then cooked by boiling or baking.'
    },
    {
      name:'Panipuri',
      img:'https://image.shutterstock.com/image-photo/panipuri-golgappa-common-street-snack-260nw-1133137268.jpg',
      description:'Panipuri is a type of snack from UP/Bihar region of the Indian subcontinent. It consists of a round, hollow puri, deep-fried crisp crepe and filled with a mixture of flavored water, tamarind chutney, chili, chaat masala, potato, onion or chickpeas.'
    },
    {
      name:'BisibeleBath',
      img:'https://cdn.pixabay.com/photo/2015/03/23/07/25/bisibellabath-685649__340.jpg',
      description:'bisibele bhath or bisibele rice with detailed photo and video recipe. ... an authentic and tasty recipe for bisi bele bath rice with a recipe for bisibelabath masala too. ... basically i prepare the spice powder or bisibelabath masala in advance and add it accordingly when i prepare bisi ..'
    },
    {
      name:'Roti',
      img:'https://cdn.pixabay.com/photo/2017/05/06/19/25/maharashtra-2290606_960_720.jpg',
      description:' Roti or Phulka Recipe with step by step photos and tips. ... these rotis or flat breads are made from whole wheat flour and water. ... the whole wheat flour which is '
    },
    {
      name:'Maggi',
      img:'https://image.shutterstock.com/image-photo/maggie-spicy-noodles-instant-260nw-696121966.jpg',
      description:'Instructions. Boil 1 1/2 cups water in a pan and add Maggi Noodles and Tastemaker. Simmer for two minutes till the Maggi is fully cooked. Meanwhile, beat an egg till frothy. Add the egg to the Maggi once the maggi is cooked and cook till the egg cooks through and is scrambled. Top with cheese and mix. Serve immediately ..'
    },
    {
      name:'Chapati',
      img:'https://image.shutterstock.com/image-photo/homemade-fresh-wheat-flour-chapathihomemade-260nw-226468174.jpg',
      description:'"A simple but delicious recipe for Indian flatbread. Serve with Indian curry, main dishes, or even use to make sandwich wraps. ... In a large bowl, stir together the whole wheat flour, all-purpose flour and salt.'
    },
  ]

 
  sendRecipies(recipies){
    this.recipiesData=recipies;
  }
  constructor() { }

  ngOnInit() {
  }

}
