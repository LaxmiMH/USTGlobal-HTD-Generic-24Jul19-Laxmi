import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  newsData: any='';
  news=[
    {
     name:'Weathernews',
      img:'https://image.shutterstock.com/image-photo/weather-forecast-television-anchorwoman-studio-260nw-644593888.jpg',
      description: 'Weather News and Analysis: Get the latest weather news, forecast, updates, and analysis across all parts of India including weather news and updates for Indian '
    },
    {
      name:'Healthnews',
      img:'https://image.shutterstock.com/image-photo/health-news-260nw-148057970.jpg',
      description:'Healthline News reports on emerging research, new treatments, diet, exercise, and trending topics in health and wellness. All articles are written by our network'},
    {
      name:'Science and technology',
      img:'https://cdn.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507__340.jpg',
      description:'Online magazine for scientists: open access, ethics, career, policy, lifestyle. Funding. Career. Ethics. RRI. Interviews. Policy. Scientists lifestyle. Innovation. Science and society. Highlights: A Team Of Experts, Online Donation Options Available'
    },
    {
      name:'Business',
      img:'https://image.shutterstock.com/image-photo/multi-nationality-business-people-talk-260nw-400584913.jpg',
      description:'Business News Today: Get all the Latest Business News, Economy News, India and International Business News on the Economic Times. Read Business News ...'},
    {
      name:'ForeignNews',
      img:'https://image.shutterstock.com/image-photo/import-freight-international-transportation-concept-260nw-375750535.jpg',
      description:'BBC News. ... Minister Bheki Cele, who inspected the operation areas, said the owner of the guns claimed to own a legitimate security firm, IOL news site reports.'
    },
    {
      name:'ShareMarketNews',
      img:'https://image.shutterstock.com/image-photo/tablet-news-website-on-stack-260nw-1059533777.jpg',
      description:'Business News Today: Get all the Latest Business News, Economy News, India and International Business News on the Economic Times. Read Business News ...'},

    {
      name:'Sports News',
      img:'https://cdn.pixabay.com/photo/2015/04/20/13/44/sports-731506__340.jpg',
      description:'cricket1st ODI: With Shikhar Dhawan back, KL Rahul could be back at No. 41 sec ago. football I-League clubs will take legal recourse if FIFA doesnt intervene1 sec ago. ... Live Cricket Score.'
     },
    {
      name:'Political News',
      img:'https://cdn.pixabay.com/photo/2018/07/01/13/28/announcement-3509489__340.jpg',
      description:'Amit Shah Says J&K, Including PoK, Integral to India; Cong Calls Article 370 Move Constitutional Travesty Amid Mutiny Over Article 370, Congress Needs to Learn from Gandhi Family Friendship With Abdullahs. ... Senior BJP Leader and Former Foreign Minister Sushma Swaraj Passes Away.'
    },
  
  ]

 
  sendNews(news){
    this.newsData=news;
  }
  constructor() { }

  ngOnInit() {
  }

}
