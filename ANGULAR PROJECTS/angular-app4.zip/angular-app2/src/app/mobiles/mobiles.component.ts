import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mobiles',
  templateUrl: './mobiles.component.html',
  styleUrls: ['./mobiles.component.css']
})
export class MobilesComponent implements OnInit {
  mobileData: any='';
  mobiles=[
    {
     brand:'sony',
      img:'https://cdn.pixabay.com/photo/2016/03/27/16/24/smartphone-1283012__340.jpg',
      description: 'Xperia range that started off .-Benz offers 19 car models in India, including 7 new car models in SUV/MUV category, 6 in Sedan category, 3 in Convertible category, 1 in Station Wagon category, 2 in Coupe category.Mercedes-Benz car price starts at Rs 31.72 Lakhs, the top line model costs Rs 2.33 Crore'
    },
    {
      brand:'samsung',
      img:'https://cdn.pixabay.com/photo/2016/03/27/19/43/smartphone-1283938__340.jpg',
      description:'If you are fond of Samsung phones. then this one is best page for you to drill down all latest models of Samsung mobiles with their price, specifications and features. Samsung Dual-sim Mobile Price List.'
    },
    {
      brand:'LG',
      img:'https://cdn.pixabay.com/photo/2015/08/07/00/41/lg-878843__340.jpg',
      description:'If you are fond of lg phones. then this one is best page for you to drill down all latest models of Samsung mobiles with their price, specifications and features. Samsung Dual-sim Mobile Price List.'},
    {
      brand:'Lenovo',
      img:'https://cdn.pixabay.com/photo/2015/08/07/00/34/lenovo-878838__340.jpg',
      description:'If you are fond of lenovo phones. then this one is best page for you to drill down all latest models of Samsung mobiles with their price, specifications and features. Samsung Dual-sim Mobile Price List.'
    },
    {
      brand:'oneplus',
      img:'https://cdn.pixabay.com/photo/2017/08/02/11/38/smartphone-2571128__340.jpg',
      description:'Check out the Best Oneplus Models Price, Specifications, Features and User Ratings at MySmartPrice. Compare the Latest Oneplus Mobile Prices and Read ...'
    },
    {
      brand:'oppo',
      img:'https://cdn.pixabay.com/photo/2018/05/16/13/27/girl-with-mobile-3405761__340.jpg',
      description:'oppo mobiles in India offers 4 Models in price range of Rs.3.50 crore to Rs. 5.20 ... Ferrari cars price starts at Rs. 3.50 crore for the cheapest car Portofino and goes up to Rs. 5.20 crore for the top model Ferrari 812 Superfast. ... Ferrari 488 question'
    },
    {
      brand:'motorola',
      img:'https://cdn.pixabay.com/photo/2017/08/06/18/16/mobile-2594848__340.jpg',
      description:'motorola prices start(GST Included) at Rs 40.61 Lakh for the most inexpensive model in its lineup, the XE. ... The Jaguar XJ, Jaguar XF, Jaguar XE are amongst the most popular cars in their respective segments. Upcoming Jaguar cars in India include the XE 2019, E Pace, I-Pace.'
    },
    {
      brand:'apple',
      img:'https://cdn.pixabay.com/photo/2014/08/05/10/27/iphone-410311__340.jpg',
      description:'apple WORLDWIDE .... Opel will use reasonable efforts to ensure that the contents of this Site are accurate and up to date but does not accept any liability for .'
    },
    {
      brand:'HTC',
      img:'https://cdn.pixabay.com/photo/2015/08/07/00/38/htc-878840__340.jpg',
      description:'HTC Mobile price list gives price in India of all HTC mobile phones, including latest HTC phones, best phones under 10000. Find lowest price to help you buy '
    },
    {
      brand:'Nokia',
      img:'https://cdn.pixabay.com/photo/2015/02/04/15/23/nokia-623939__340.jpg',
      description:'Price list of all Nokia mobile phones in India with specifications and features from different online stores at 91mobiles. Read user reviews, compare mobile prices and ask questions. ... Nokia 6.1 Plus (Nokia X6'
    },
  ]

 
  sendMobile(mobile){
    this.mobileData=mobile;
  }

  constructor() { }

  ngOnInit() {
  }

}
