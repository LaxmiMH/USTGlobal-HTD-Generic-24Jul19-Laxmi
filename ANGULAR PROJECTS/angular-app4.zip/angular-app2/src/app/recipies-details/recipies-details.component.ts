import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-recipies-details',
  templateUrl: './recipies-details.component.html',
  styleUrls: ['./recipies-details.component.css']
})
export class RecipiesDetailsComponent implements OnInit {
  @Input() recipiesDetails: any='';
  constructor() { }

  ngOnInit() {
  }

}
