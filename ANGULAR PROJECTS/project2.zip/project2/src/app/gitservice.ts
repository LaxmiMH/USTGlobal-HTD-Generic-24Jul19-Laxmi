import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class GitService {

  url: string = 'https://api.github.com/users';
  constructor(public http: HttpClient) { }
  users : any = [];
  handleError: any = [];
  
    getData() {

   return this.http.get<any>(`${this.url}`).
    subscribe( data => {
      this.users = data;
    }, err => {
      console.log(err);
    } );
  }
 
      // delete() {
      //        return  this.http.delete<void>(`${this.url}`).pipe((resData => {
      //       )).subscribe(data=>{
      //       },err=>{
      //          console.log(err);
      //        }
      //      );
      //        }
              // delete(id: number) {
              //   return  this.http.delete(`${this.url}`).pipe(map(resData => {
              //           let   userarray = [];
              //           for(let key in resData){
              //             userarray.push({...resData[key], id: key} );
              //           }
              //           return userarray;
              //         }));
              //           }
                        // deleteData(key) {
                        //        return  this.http.delete(`${this.url}/${key}`).pipe(map(resData => {
                        //          let   userarray = [];
                        //          for(let key in resData){
                        //            userarray.pop();
                        //          }
                        //          return userarray;
                        //        })).subscribe(data=>{
                        //          this.users=data},err=>{
                        //          console.log(err);
                        //        }
                        //      );
                        //      }
                            //  deleteData(id: number): Observable<{}> {
                            //   const url = `${this.url}/${id}`; // DELETE api/heroes/42
                            //   return this.http.delete(url)
                            //     .pipe(
                            //       catchError(this.handleError('deleteData'))
                            //     );
                            // }
                            delteData() {
                                //  return  this.http.get(`${this.url}`).pipe(map(resData => {
                                //     let   userarray = [];
                                //     for(let key in resData){
                                //       userarray.push({...resData[key], id: key} );
                                //     }     
                                //     return userarray;
                                //   }))
                                    // }
                                  
                                   }
                                  }
                                  //  delteData(data){
                                  //    return this.http.delete(`${this.url}/${data.id}`)
                                  //  }
                      


