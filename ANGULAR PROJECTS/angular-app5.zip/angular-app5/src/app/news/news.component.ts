import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-news',
  templateUrl: './news.component.html',
  styleUrls: ['./news.component.css']
})
export class NewsComponent implements OnInit {
  sportnew:any=[];
 indiannews:any[]=[];
 Technews:any=[];
  constructor(private http: HttpClient) {
    http.get <any>('https://newsapi.org/v2/top-headlines?category=sports&apiKey=9729e7f9f118468bb9c4d0358a582e8f')
    .subscribe(resData=>{
      this.sportnew=resData.articles;
      console.log(this.sportnew);
    }),
    http.get <any>('https://newsapi.org/v2/top-headlines?country=us&apiKey=9729e7f9f118468bb9c4d0358a582e8f')
    .subscribe(resData=>{
      this.indiannews=resData.articles;
      console.log(this.indiannews);
    }),
    http.get <any>('https://newsapi.org/v2/top-headlines?category=technology&apiKey=9729e7f9f118468bb9c4d0358a582e8f')
    .subscribe(resData=>{
      this.Technews=resData.articles;
      console.log(this.Technews);
    })
  }
 

  ngOnInit() {
  }

}
