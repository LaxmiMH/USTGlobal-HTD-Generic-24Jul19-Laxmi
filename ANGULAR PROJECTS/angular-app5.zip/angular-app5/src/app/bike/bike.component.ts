import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-bike',
  templateUrl: './bike.component.html',
  styleUrls: ['./bike.component.css']
})
export class BikeComponent implements OnInit {
  bikedata='';
  bikes=[{
    name:'Weathernews',
     img:'https://image.shutterstock.com/image-photo/weather-forecast-television-anchorwoman-studio-260nw-644593888.jpg',
     description: 'Weather News and Analysis: Get the latest weather news, forecast, updates, and analysis across all parts of India including weather news and updates for Indian '
   },
   {
     name:'Healthnews',
     img:'https://image.shutterstock.com/image-photo/health-news-260nw-148057970.jpg',
     description:'Healthline News reports on emerging research, new treatments, diet, exercise, and trending topics in health and wellness. All articles are written by our network'},
   {
     name:'Science and technology',
     img:'https://cdn.pixabay.com/photo/2018/05/08/08/44/artificial-intelligence-3382507__340.jpg',
     description:'Online magazine for scientists: open access, ethics, career, policy, lifestyle. Funding. Career. Ethics. RRI. Interviews. Policy. Scientists lifestyle. Innovation. Science and society. Highlights: A Team Of Experts, Online Donation Options Available'
   }]

  constructor() { }

  ngOnInit() {
  }
  sendBikes(bike){
    this.bikedata=bike;
  }
}
