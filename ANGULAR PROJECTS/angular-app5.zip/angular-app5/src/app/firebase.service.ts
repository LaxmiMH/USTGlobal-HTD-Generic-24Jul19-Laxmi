import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  url: string ='https://api.github.com/users'
  url1:string ='https://jsonplaceholder.typicode.com/posts'

  constructor(private http: HttpClient) { }
  users=[];

  getData(){
    return this.http.get(`${this.url}`).pipe(map(resData =>{
      let userarray=[];
      for(let key in resData){
        userarray.push({...resData[key], id: key} );
      }
      return userarray;
    })).subscribe(data=>{
      this.users=data;
    },err=>{
        console.log(err);
      }
    );
  }


users1=[];
getData1(){
  return this.http.get(`${this.url1}`).pipe(map(resData =>{
    let userarray1=[];
    for(let key in resData){
      userarray1.push({...resData[key], id: key} );
    }
    return userarray1;
  })).subscribe(data=>{
    this.users1=data;
  },err=>{
      console.log(err);
    }
  );
}
}
