import { Component, OnInit } from '@angular/core';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-place-holder',
  templateUrl: './place-holder.component.html',
  styleUrls: ['./place-holder.component.css']
})
export class PlaceHolderComponent implements OnInit {

  constructor(private firebaseService:FirebaseService) { }

  ngOnInit() {
    this.firebaseService.getData1();
    console.log(this.firebaseService.users1);
  }

}
