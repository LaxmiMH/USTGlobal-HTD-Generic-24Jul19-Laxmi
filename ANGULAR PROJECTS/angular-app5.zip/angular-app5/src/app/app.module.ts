import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './header/header.component';
import { NewsComponent } from './news/news.component';
import { BusinessComponent } from './business/business.component';
import {  HttpClientModule } from '@angular/common/http';
import { GitComponent } from './git/git.component';
import { PlaceHolderComponent } from './place-holder/place-holder.component';
import { BikeComponent } from './bike/bike.component';
import { BikedetailsComponent } from './bikedetails/bikedetails.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    NewsComponent,
    BusinessComponent,
    GitComponent,
    PlaceHolderComponent,
    BikeComponent,
    BikedetailsComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
