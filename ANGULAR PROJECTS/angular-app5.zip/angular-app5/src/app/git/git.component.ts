import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FirebaseService } from '../firebase.service';

@Component({
  selector: 'app-git',
  templateUrl: './git.component.html',
  styleUrls: ['./git.component.css']
})
export class GitComponent implements OnInit {
  sportnew:any=[];

  constructor(private firebaseService:FirebaseService) {
  
  }


  ngOnInit() {
    this.firebaseService.getData();
    console.log(this.firebaseService.users)
  }

}
