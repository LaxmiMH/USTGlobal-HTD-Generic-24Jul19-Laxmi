import { Component, OnInit } from '@angular/core';
import{ HttpClient }from '@angular/common/http';
import { from } from 'rxjs';

@Component({
  selector: 'app-business',
  templateUrl: './business.component.html',
  styleUrls: ['./business.component.css']
})
export class BusinessComponent implements OnInit {
businessnew:any=[];
  constructor( private http:HttpClient) { 
   http.get<any>('https://newsapi.org/v2/top-headlines?category=business&apiKey=9729e7f9f118468bb9c4d0358a582e8f')
   .subscribe(resData=>{
    this.businessnew=resData.articles;
    console.log(this.businessnew);
  })
  
  }

  ngOnInit() {
  }

}
