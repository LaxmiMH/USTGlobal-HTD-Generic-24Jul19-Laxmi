import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewsComponent } from './news/news.component';
import { BusinessComponent } from './business/business.component';
import { GitComponent } from './git/git.component';
import { PlaceHolderComponent } from './place-holder/place-holder.component';
import { BikeComponent } from './bike/bike.component';


const routes: Routes = [ {path:'',component:NewsComponent},
       {path:'business',component:BusinessComponent},
       { path: 'git', component: GitComponent},
       { path:'place',component:PlaceHolderComponent},
       {path:'bike',component:BikeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
