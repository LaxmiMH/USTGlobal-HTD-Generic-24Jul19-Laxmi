import { MyDirectiveDirective } from './my-directive.directive';

describe('MyDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MyDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
