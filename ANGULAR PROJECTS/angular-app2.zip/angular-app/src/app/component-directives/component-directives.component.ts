import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-component-directives',
  templateUrl: './component-directives.component.html',
  styleUrls: ['./component-directives.component.css']
})
export class ComponentDirectivesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
