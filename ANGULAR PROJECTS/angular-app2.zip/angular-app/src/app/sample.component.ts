// import { Component } from '@angular/core';

 
// @Component({
//     selector : 'app-sample',
//     template :
//     `<h1> Sample component is working</h1>`,
//     styles : [`h1{background :red; color: white}`]
// }) 
 
//  export class SampleComponent{

// }
import { Component } from '@angular/core';

 
@Component({
    selector : 'app-sample',
  templateUrl :`./sample.component.html`,
  styleUrls:['./sample.component.css']
}) 
 
 export class SampleComponent{

}