import { Component, OnInit, OnDestroy } from '@angular/core';
import { UserService } from '../user.service';
// import { interval } from 'rxjs';
// import { map } from 'rxjs/operators';

@Component({
  selector: 'app-observables',
  templateUrl: './observables.component.html',
  styleUrls: ['./observables.component.css']
})
export class ObservablesComponent implements OnInit,OnDestroy {
  mysubscribe: any='';
  constructor( private userservice: UserService) { }

 
 
 
  ngOnInit() {
    // this. mysubscribe=interval(1000).pipe(map(data=>{
    //   return data*10;
    // })).subscribe(data=>{
    //   console.log(data);
    // }, error=>{
    //   console.log(error);
    // },()=>{
    //   console.log('sub complete');
    // });
    this.userservice.printdetail()
  }
  ngOnDestroy(){
// this.mysubscribe.unsubscribe();
  }

}
