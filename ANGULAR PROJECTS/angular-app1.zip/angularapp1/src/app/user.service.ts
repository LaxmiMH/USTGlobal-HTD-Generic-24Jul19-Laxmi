import { Injectable } from '@angular/core';

 @Injectable({
     providedIn: "root"
 })
 export class UserService{
users= [
    {
      name:'laxmi',
      company:'ust'
      },
    {
        name:'shreeram',
        company:'google'
    },
    

];

printdetail(){
    console.log("the function of service executed");
}
}