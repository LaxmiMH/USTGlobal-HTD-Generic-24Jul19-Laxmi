namespace mathoper{
    // export namespace Cir{
    const PI=3.14;
     export function circum1(r:number){
         console.log(2*PI*r);
     }
     function area(r:number){
         console.log(PI*r*r);
     }

}
// }
 mathoper.circum1(3);