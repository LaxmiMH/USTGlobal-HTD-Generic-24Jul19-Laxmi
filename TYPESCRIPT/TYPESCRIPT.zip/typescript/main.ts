import{Student} from './student';
let student1=new Student();
console.log(student1.name);