//  namespace MathOperation{
//     const PI=3.14;
//      export function circumferenceofCirlce(radius:number){
//         console.log("the cicum is"+2*PI*radius);
//     }
//     function area(radius:number){
//         console.log(PI*radius*radius); 
//     }
//     MathOperation.circumferenceofCirlce(3);
    
//  }

namespace MathOperation{
    export namespace Circle{
    const PI=3.14;
     export function circumferenceofCirlce(radius:number){
        console.log("the cicum is"+2*PI*radius);
    }
    function area(radius:number){
        console.log(PI*radius*radius); 
    }
}

 }
