namespace RectangleOperation{
    export namespace rectangle{
        export function area(length:number,bredth:number){
            console.log('area is '+length*bredth);
        }
        export function peri(length:number,bredth:number){
            console.log('peri is '+2*(length+bredth));
        }
    }
}