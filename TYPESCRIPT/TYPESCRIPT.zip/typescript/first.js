// /// <reference path=" ./circle.ts" />
// // / <reference path="./rectangle.ts"/>
// MathOperation.Circle.circumferenceofCirlce(4);
var myname = "laxmi";
alert(myname);
console.log(myname);
var company; /*it implicistly take anytype so no error*/
company = 'ust';
company = 20;
console.log(company);
// console.log(myname);
var sample; //it take only string and number it is called as union
sample = 10;
sample = 'na';
console.log(sample); // it show error bcz of boolean
var myarray = [1345, 'kdnkjd', 'afkj', true];
var marray = ['kdnkjd', 'afkj'];
console.log(myarray);
console.log(marray);
var mytuple = ['laxmi', 21, false]; //we have to give in the order of data type i.e tuple
console.log(mytuple);
var colors;
(function (colors) {
    colors["red"] = "danger";
    colors["green"] = "success";
    colors[colors["blue"] = 25] = "blue";
    colors["black"] = "dark";
})(colors || (colors = {}));
console.log(colors.blue);
var Person = /** @class */ (function () {
    function Person(pname, page) {
        this.pname = pname;
        this.page = page;
        this.name = 'laxmi'; //public
        this.name = pname;
        this.age = page;
    }
    return Person;
}());
var person1 = new Person('shree', 12);
console.log(person1.page);
// // // let myname='shree';
// // // myname=null;  //if we want to initilize nstricknull check file should be false in json
// class Car{
//     brand:string='BMW';//aces this using refernce variable
//  static    model:string='x5';//we acess this variable by using class name
//     // constructor(public brand1:string,public model1:string){
//     // }
// // }
// // // let car=new Car();
// // // console.log(car.brand);   //here we use reference name to access
// // // console.log(Car.model);  //here we use class name to access
// // // let bmwcar=new Car('bmw','x5');
// // // console.log(bmwcar.brand1);
// // // console.log(bmwcar.model1);
// // let benzcar:Car ={          //creating object
// //     brand:'benz',
// //     model:'000',
// //}
// // console.log(benzcar.brand);
// class Person{
//     salary:number=5678;
//     constructor(public name:string,public age:number){
//     }
// }
// class student extends Person{
// constructor(public myname:string,public myage:number,public usn:number){
//     super(myname,myage);
// }
// }
// let person1=new Person('dings',23);
// let student1=new student('guldu',34,9999);
// console.log(student1.salary);
// console.log(person1);
// class Person{
//     name:string='amm';
//     age:number=34;
// }
// class student extends Person{
// }
// class Person{
//     constructor(public name:string,public age:number,public degree ?: string){}
// }
// let person1:Person={
//     name:'jakfbka',
//     age:34
// }
// let person2:Person={
//     name:'xyz',
//     age:35,
//     degree:'eng'
// }
// console.log(person2); 
// interface Student{             //only declaration will be there there is no initilzation
//     name:string;
//     age:number;
//     printDetails(): void;          //only abstract methods are there in interface
// }
// class Person implements Student{        //for inherit interface we use implemnts and  provide impliment to the method
// name='fknfsdkk';
// age=23;
// printDetails(){
//     console.log("name is"+this.name+"age is"+this.age);
// }
// }
// let person1=new Person();
// person1.printDetails();
// let student1:Student={        //object creation for implement
//     name:'xy',
//     age:20,
//     printDetails  : ()=> {
//         console.log("name is"+student1.name+"age is"+student1.age)  //by using stident1 we are using main class
//     }
// }
// student1.printDetails();
// function getArray(items:string[]){
//     return new Array().concat(items);
// }
// console.log(getArray(['jdjk','gfjG']));
// function getArray1<c>(items:c[]):c[]{
//     return new Array<c>().concat(items);
// }
// let strArray=getArray1<string>(['jshafbj','jagfj','fjszj']);
// let numaray=getArray1<number>([222,333])
// numaray.push(23);
// console.log(numaray);
// //  to import namespace we use this
// refecrence tag is use to import circle and rectangle
