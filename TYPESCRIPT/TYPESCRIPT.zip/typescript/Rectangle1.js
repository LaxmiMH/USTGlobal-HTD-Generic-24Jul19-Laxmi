/// <reference path="./CIR1.ts" />
mathoper.Cir.circum(3);
