var RectangleOperation;
(function (RectangleOperation) {
    var rectangle;
    (function (rectangle) {
        function area(length, bredth) {
            console.log('area is ' + length * bredth);
        }
        rectangle.area = area;
        function peri(length, bredth) {
            console.log('peri is ' + 2 * (length + bredth));
        }
        rectangle.peri = peri;
    })(rectangle = RectangleOperation.rectangle || (RectangleOperation.rectangle = {}));
})(RectangleOperation || (RectangleOperation = {}));
