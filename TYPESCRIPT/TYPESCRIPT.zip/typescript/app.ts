// /// <reference path="./circle.ts" />
// MathOperation.Circle.circumferenceofCirlce(4);
// /// <reference path="./rectangle.ts" />
//  RectangleOperation.rectangle.area(2,3);

import {Circle} from './circle.ts'