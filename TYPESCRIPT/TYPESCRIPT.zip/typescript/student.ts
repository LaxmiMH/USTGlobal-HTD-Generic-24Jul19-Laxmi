 export class Student{
    name:string='khfkah';
    printDetails(){
        console.log(this.name);
    }
}