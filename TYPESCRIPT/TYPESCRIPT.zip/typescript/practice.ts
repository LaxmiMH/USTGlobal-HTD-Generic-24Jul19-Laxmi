 let myname1: string='laxmi';
alert(myname1);
 console.log(myname1);
// let myname=true;
 let name1: string | number ;
name1='vinod';
 name1=20;
console.log(name1);
class person{
    name :string='shreeram';
    id: number=12
    constructor( ){
     

    }
}
let person2=new person();
console.log(person2.name);

class CAR{
    name: string='benz';
    static cost:string='10000';

}
let car=new CAR();
console.log(car.name);
console.log(CAR.cost);
let bmwcar:CAR={
    name:'bmw',
}
class per{
    salary:string='shree';
    constructor(public name1:string,public age:number){}

}
class student extends per{
    constructor(public  myname:string,public myage:number,public usn1:number){
        super(myname,myage);
    }
}
let per1=new per('shreeram',21)
console.log(per1);
let student1=new student('jaya',12,1111);
console.log(student1);
console.log(student1.salary);
interface Students{
    name:string;
    age:number;
    details():void;
}
class pers implements Students{
 public   name='suman';
    age=21;
    details(){
        console.log(this.name+ " "+this.age)
    }
}
console.log(pers);
let pers1=new pers();
pers1.details();
let Students1:Students={
    name:'shreeram',
    age:21,
    details:()=>{
        console.log(Students1.name);
       
    }

}
Students1.details();
let student2=new pers();
student2.details();
function getarray<c>(items:c[]){
    return new Array<c>(). concat(items);
  
}
console.log(getarray(['jdjk','gfjG']));

let stringArray=getarray<string>(['sum','roj','lax','pallu']);
console.log(stringArray);
 
let numarray=getarray<number>([111,1123]);
console.log(numarray);
 numarray.push(22118);
 console.log(numarray);
 stringArray.push('111');
 console.log(stringArray);