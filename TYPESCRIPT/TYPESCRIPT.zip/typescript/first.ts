// /// <reference path=" ./circle.ts" />
// // / <reference path="./rectangle.ts"/>
// MathOperation.Circle.circumferenceofCirlce(4);


let myname:string = "laxmi";
 alert(myname);
console.log(myname);
myname='2';
let company; /*it implicistly take anytype so no error*/
company='ust';
company=20;
console.log(company);
// console.log(myname);
let sample: number | string;//it take only string and number it is called as union
sample=10;
sample='na';
console.log(sample);// it show error bcz of boolean
let myarray: any[]=[1345,'kdnkjd','afkj',true];
let marray: string[]=['kdnkjd','afkj'];
console.log(myarray);
console.log(marray);
// let mytuple:[string,number,boolean]=['laxmi',21,false];//we have to give in the order of data type i.e tuple
// console.log(mytuple);
// enum colors{
//     red='danger',          //enum intilize evry value to number from 0 and if we inilize it go in increment order
//     green='success',   //if we pass sting we have to give values to each variable
//     blue=25,
//     black='dark'
// }

//  console.log(colors.blue);
// class Person{
//     name: string='laxmi'; //public
//     age:number;
//     constructor(public pname:string, public page:number){
//         this.name=pname;
//         this.age=page;
//     }

// }
// let person1=new Person('shree',12);
// console.log(person1.page);
// // // // let myname='shree';
// // // // myname=null;  //if we want to initilize nstricknull check file should be false in json
// class Car{
//     brand:string='BMW';//aces this using refernce variable
//  static    model:string='x5';//we acess this variable by using class name
//     constructor(public brand1:string,public model1:string){

//     }
// }
// // let car=new Car();
// // console.log(car.brand);   //here we use reference name to access
// // console.log(Car.model);  //here we use class name to access
// // let bmwcar=new Car('bmw','x5');
// // console.log(bmwcar.brand1);
// // console.log(bmwcar.model1);
// let benzcar:Car ={          //creating object
//     brand:'benz',
//     model:'000',
// }
// console.log(benzcar.brand);

// class Perso{
//     salary:number=5678;
//     constructor(public name:string,public age:number){

//     }


// }
// class studen extends Person{
// constructor(public myname:string,public myage:number,public usn:number){
//     super(myname,myage);
// }
// }
// let perso1=new Person('dings',23);
// let studen1=new student('guldu',34,22222);
// console.log(student1.salary);
// console.log(person1);
// / class Person{
// //     name:string='amm';
// //     age:number=34;
// // }
// // class student extends Person{

// // }
class Person1{
    constructor(public name:string,public age:number,public degree ?: string){}
}
let person3:Person1={
    name:'jakfbka',
    age:34
}
let person4:Person1={
    name:'xyz',
    age:35,
    degree:'eng'

}
console.log(person2); 
interface Student{             //only declaration will be there there is no initilzation
    name:string;
    age:number;
    printDetails(): void;          //only abstract methods are there in interface
}
class Person implements Student{        //for inherit interface we use implemnts and  provide impliment to the method
name='fknfsdkk';
age=23;
printDetails(){
    console.log("name is"+this.name+"age is"+this.age);
}

}
let person1=new Person();
person1.printDetails();/
// let student1:Student={        //object creation for implement
//     name:'xy',
//     age:20,
//     printDetails  : ()=> {
//         console.log("name is"+student1.name+"age is"+student1.age)  //by using stident1 we are using main class

//     }
// }
// student1.printDetails();
// function getArray(items:string[]){
//     return new Array().concat(items);
// }
// console.log(getArray(['jdjk','gfjG']));

function getArray1<c>(items:c[]):c[]{
    return new Array<c>().concat(items);
}
let strArray=getArray1<string>(['jshafbj','jagfj','fjszj']);
// let numaray=getArray1<number>([222,333])
// numaray.push(23);
// console.log(numaray);
// //  to import namespace we use this

// refecrence tag is use to import circle and rectangle

