//  namespace MathOperation{
//     const PI=3.14;
//      export function circumferenceofCirlce(radius:number){
//         console.log("the cicum is"+2*PI*radius);
//     }
//     function area(radius:number){
//         console.log(PI*radius*radius); 
//     }
//     MathOperation.circumferenceofCirlce(3);
//  }
var MathOperation;
(function (MathOperation) {
    var Circle;
    (function (Circle) {
        var PI = 3.14;
        function circumferenceofCirlce(radius) {
            console.log("the cicum is" + 2 * PI * radius);
        }
        Circle.circumferenceofCirlce = circumferenceofCirlce;
        function area(radius) {
            console.log(PI * radius * radius);
        }
    })(Circle = MathOperation.Circle || (MathOperation.Circle = {}));
})(MathOperation || (MathOperation = {}));
