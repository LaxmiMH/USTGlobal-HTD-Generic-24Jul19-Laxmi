var mathoper;
(function (mathoper) {
    // export namespace Cir{
    var PI = 3.14;
    function circum1(r) {
        console.log(2 * PI * r);
    }
    mathoper.circum1 = circum1;
    function area(r) {
        console.log(PI * r * r);
    }
})(mathoper || (mathoper = {}));
// }
mathoper.circum1(3);
