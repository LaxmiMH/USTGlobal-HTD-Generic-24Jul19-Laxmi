var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var myname1 = 'laxmi';
alert(myname1);
console.log(myname1);
// let myname=true;
var name1;
name1 = 'vinod';
name1 = 20;
console.log(name1);
var person = /** @class */ (function () {
    function person() {
        this.name = 'shreeram';
        this.id = 12;
    }
    return person;
}());
var person2 = new person();
console.log(person2.name);
var CAR = /** @class */ (function () {
    function CAR() {
        this.name = 'benz';
    }
    CAR.cost = '10000';
    return CAR;
}());
var car = new CAR();
console.log(car.name);
console.log(CAR.cost);
var bmwcar = {
    name: 'bmw'
};
var per = /** @class */ (function () {
    function per(name1, age) {
        this.name1 = name1;
        this.age = age;
        this.salary = 'shree';
    }
    return per;
}());
var student = /** @class */ (function (_super) {
    __extends(student, _super);
    function student(myname, myage, usn1) {
        var _this = _super.call(this, myname, myage) || this;
        _this.myname = myname;
        _this.myage = myage;
        _this.usn1 = usn1;
        return _this;
    }
    return student;
}(per));
var per1 = new per('shreeram', 21);
console.log(per1);
var student1 = new student('jaya', 12, 1111);
console.log(student1);
console.log(student1.salary);
var pers = /** @class */ (function () {
    function pers() {
        this.name = 'suman';
        this.age = 21;
    }
    pers.prototype.details = function () {
        console.log(this.name + " " + this.age);
    };
    return pers;
}());
console.log(pers);
var pers1 = new pers();
pers1.details();
var Students1 = {
    name: 'shreeram',
    age: 21,
    details: function () {
        console.log(Students1.name);
    }
};
Students1.details();
var student2 = new pers();
student2.details();
function getarray(items) {
    return new Array().concat(items);
}
console.log(getarray(['jdjk', 'gfjG']));
var stringArray = getarray(['sum', 'roj', 'lax', 'pallu']);
console.log(stringArray);
var numarray = getarray([111, 1123]);
console.log(numarray);
numarray.push(22118);
console.log(numarray);
