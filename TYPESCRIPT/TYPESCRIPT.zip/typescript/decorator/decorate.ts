function printconstructor(mine:Function){      //to use this as decorator
    console.log(mine);
}

@printconstructor                        //this way use decorrator
class Sample{
    constructor(){
        console.log('hi heloo i am sample constructor');
    }
}

