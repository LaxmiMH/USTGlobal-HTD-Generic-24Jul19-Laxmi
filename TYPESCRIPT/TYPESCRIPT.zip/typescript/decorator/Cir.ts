namespace mathoper{
    const PI=3.14;
     export function circum(r:number){
         console.log(2*PI*r);
     }

}
mathoper.circum(3);