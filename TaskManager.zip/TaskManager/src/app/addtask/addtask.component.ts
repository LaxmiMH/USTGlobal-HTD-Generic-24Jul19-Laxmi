import { Component, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { Router } from '@angular/router';

@Component({
  selector: 'app-addtask',
  templateUrl: './addtask.component.html',
  styleUrls: ['./addtask.component.css']
})
export class AddtaskComponent implements OnInit {
  adddata='';
added=[];
  constructor(private router : Router) { }
  send(addTask:NgForm){
    console.log(addTask.value);
    this.added.push(addTask.value);
     this.adddata=addTask.value;
    this.router.navigateByUrl('/view');
    addTask.reset();
    console.log(this.added);
   }
  ngOnInit() {
  }

}
