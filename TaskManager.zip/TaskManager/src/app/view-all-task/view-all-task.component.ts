import { Component, OnInit, Input, Output } from '@angular/core';

@Component({
  selector: 'app-view-all-task',
  templateUrl: './view-all-task.component.html',
  styleUrls: ['./view-all-task.component.css']
})
export class ViewAllTaskComponent implements OnInit {
@Output() data='';
  
  constructor() { }

  ngOnInit() {
  
  }

}
