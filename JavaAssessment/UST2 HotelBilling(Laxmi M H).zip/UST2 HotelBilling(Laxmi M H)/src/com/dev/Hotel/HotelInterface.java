package com.dev.Hotel;

public interface HotelInterface {
	public Items addItem(int itemcode,Items i);
	public Items removeItem(int itemcode);
	public void searchItem(int itemcode);
}
