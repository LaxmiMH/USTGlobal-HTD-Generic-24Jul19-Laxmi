package com.dev.Hotel;

import java.util.HashMap;
import java.util.Scanner;



public class HotelImplementation  implements HotelInterface{

	HashMap<Integer,Items> hm = new HashMap<Integer,Items>();

	@Override
	public Items addItem(int itemcode, Items i) {
		if(i!=null) {
			hm.put(itemcode, i );
			Items m = hm.put(itemcode, i);
			if(m!=null) {
				return i;
			}
		}
		return null;
	}

	@Override
	public Items removeItem(int itemcode) {
		Items k =hm.remove(itemcode);
		return k;
	}

	@Override
	public void searchItem(int itemcode) {
		System.out.println(hm.get(itemcode));

	}

	//to update any items
	public void update(int itemcode) {
		Items e1 = hm.get(itemcode);
		e1.setFoodname("puliyogare");
		hm.put(itemcode, e1);
	}


	public void display(){
		System.out.println(hm);

	}

	//	public void netbill(int itemcode) {
	//		
	//	}

	public static void main(String[] args) {
		HotelImplementation ho = new HotelImplementation();
		Scanner sc= new Scanner(System.in);

		Items i = new Items();
		i.setItemcode(1);
		i.setFoodname("dosa");
		i.setPrice(50);

		Items i1 = new Items();
		i1.setItemcode(2);
		i1.setFoodname("Biriyani");
		i1.setPrice(100);

		Items i2 = new Items();
		i2.setItemcode(3);
		i2.setFoodname("chicken kabab");
		i2.setPrice(200);

		Items m = ho.addItem(1, i);
		Items m1 = ho.addItem(2, i1);

		//to display all items
		System.out.println("press 1 to dispaly the items: ");
		int item = sc.nextInt();
		ho.display();

		//to perform any changes in the items
		System.out.println("press 3 for the changes in items: ");
		int item1 = sc.nextInt();
		System.out.println("press 4 to  add chicken kabab item: ");
		int item2 = sc.nextInt();
		ho.addItem(3, i2); //to add item
		ho.display();

		System.out.println("press 5  to remove the biriyani: ");
		int item3 = sc.nextInt();
		ho.removeItem(2);
		ho.display();

		System.out.println("press 6 to change chicken kabab to puliyogare: ");
		int item4=sc.nextInt();
		ho.update(3);
		ho.display();

		System.out.println("press 8 to check dosa is avilable or not: ");
		int item5=sc.nextInt();
		ho.searchItem(1);

	}
}
