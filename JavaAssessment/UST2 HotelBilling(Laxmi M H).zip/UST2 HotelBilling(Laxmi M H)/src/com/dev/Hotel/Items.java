package com.dev.Hotel;

public class Items {
	private int itemcode;
	private String foodname;
	private double price;
	public int getItemcode() {
		return itemcode;
	}
	public void setItemcode(int itemcode) {
		this.itemcode = itemcode;
	}
	public String getFoodname() {
		return foodname;
	}
	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	@Override
	public String toString() {
		return "HotelBill [itemcode=" + itemcode + ", foodname=" + foodname + ", price=" + price + "]";
	}

}
