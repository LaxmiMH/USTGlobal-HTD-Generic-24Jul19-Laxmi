var tree= {
    height:200,
    leavesclr:'green',
    fruit:'apple',
    getfruit :function()
    {
        return this.fruit;
    }
    
}
console.log(tree);
var fruit=tree.getfruit();
console.log('fruit='+fruit);
  

var Bus={
    
    clr:'white',
    price:10000,
   
}
console.log(Bus);
var house={
    area: 'btm',
    hNo:19,
    gethNo: function()
    {
        return this.hNo;
    }
}
var hNo=house.gethNo();
console.log('hno='+hNo);

console.log("*******");
var person=new Object();
person.name='kkkkk';
person.age=12;
console.log(person.name);
console.log(person.age);

var hotel=new Object();
hotel.name="krishna";
console.log(hotel.name);

var veh=new Object()
veh.name='honda'
console.log(veh.name);

console.log('*****');
var names=['pallavi','laxmi','suma','roja'];
 var name1=names[1];
console.log('name1='+name1);
for(var i=0;i<names.length;i++)
{
    console.log(names[i]);
}
console.log('////');

var names1=new Array('jaya','shree','deepa');
console.log(names1[1]);

for(i=0;i<=5;i++)
{
    var names1=new Array('jaya','shree','deepa','kkk');
console.log(names1[i]);

}








 
