window.alert("hello");
alert('hello world');
 let isadult=confirm('are you adult');
 console.log('Is adult='+isadult);
 let name=prompt('what is ur name');
console.log('my name is='+   name);