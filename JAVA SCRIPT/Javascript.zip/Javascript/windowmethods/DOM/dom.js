//  get elment by id
 let pelement=document.getElementById('demo');
 console.log(pelement);
 pelement.textContent='this is new p tag';
 
 //get element by className()
 let divelements=document.getElementsByClassName('blue');
 console.log(divelements);
 let pelements=document.getElementsByTagName('p');
 console.log(pelements);
 let element=document.getElementsByName('helment');
 console.log(element);
 let demoelement=document.querySelector('#demo');
 console.log(demoelement);
 let blueclasselements=document.querySelectorAll('.blue');
 console.log(blueclasselements);
 let buttonelement=document.createElement('button');
 buttonelement.textContent='click me';
 console.log(buttonelement);
document.body.appendChild(buttonelement);
let spanelement=document.getElementById('spanid')
spanelement.style.color='blue'
let buttonelement1=document.getElementById('buttonele')
buttonelement1.classList='add';
buttonelement1.classList='add add1';
// let pe=document.getElementById('demo1');
// pe.style.color='blue';
//pe.className='blue';
//pe.classList= 'blue  fonts';
let mine=document.write('suman','laxmi');
console.log(mine);
let object=document.createElement('h1');
object.textContent='hiii';
console.log(object);
let pel=document.getElementById('demo1');
console.log(pel);
pel.textContent='this is tag';
let tag=document.getElementsByTagName('h1');
console.log(tag);
document.body.appendChild(object);
let mine1=document.getElementsByClassName('blue');
console.log(mine1);
let mine2=document.querySelector('.blue');
console.log(mine2);
let mine3=document.querySelectorAll('.blue');
console.log(mine3);
var m1=2+3+"hello";
console.log(m1);
var k1="hi"+23+78;
console.log(k1);
var m=3+4+"5"+3;
console.log(m);
var k="3"+4+5;
console.log(k);