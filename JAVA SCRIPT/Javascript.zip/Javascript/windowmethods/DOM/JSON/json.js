let employeeJSON={
                  name:'guldu',
                  age:24,
                  hobbies: ['dancing','singing']
                  }
console.log(`my name is ${employeeJSON.name}`) //this is called string interpolation insteda of concatination we use
  console.log(employeeJSON);  //this prints objects
   let jsonobject=JSON.stringify(employeeJSON);//it convert object in to string
   console.log(jsonobject);
 let jsobject=  JSON.parse(jsonobject); //parse converts jsonobjects to jsobect
 console.log(jsobject);
 //to get the objects behavious there is a method is called as objectde structuring
 const ho=['sing','dace'];
 let [h1,h2]=ho;
 console.log(h1);
 //object  destructuring
 const employee={
   name:'shreeram',
   id:24
 }
 let{name,id}=employee;
 console.log(employee.name);