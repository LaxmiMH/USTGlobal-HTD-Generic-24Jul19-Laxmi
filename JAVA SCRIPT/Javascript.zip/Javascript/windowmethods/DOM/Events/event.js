function sayhello(){
    alert('hello')
}
let buttonele=document.getElementById('clickbutton')
buttonele.onclick=function(){
    alert('hello world');
}
/*let ele=document.createElement('button');
ele.textContent='clickkk';
console.log(ele);
document.body.appendChild(ele);*/
function createpelement(){
    let pele=document.createElement('p');
    pele.textContent='this is p elmemt';
    document.body.appendChild(pele);
}
 let alertele=document.getElementById('alertHi')
 alertele.addEventListener('click',function(){
     alert('good eve');
 });
 let h1ele= document.createElement('h1');
  function showText(){
      let inputelement=document.getElementById('showdata');
      console.log(inputelement.value);
    //   let h1ele= document.createElement('h1');from this we get many elemnrts in sam page
     h1ele.textContent=inputelement.value;
     document.body.appendChild(h1ele);
  }