function fact(n){
    if(n===0 || n===1){
        return 1;
    }else{
        return fact(n-1)*n;
    }
}
let factorial= fact(5);
console.log(factorial);
function sum(a,b,...rest){    
    return a+b;

}
let sum1=sum(3,2,3,4);   //if we write rest that that fun perform operation based on how much it want
console.log(sum1);
 let obj1={
     name:'shree',
     age:12
 }
 let obj2={
    name:'soubagya',
    age:23
}
 let obj3={ obj1,...obj2};
 console.log(obj3);