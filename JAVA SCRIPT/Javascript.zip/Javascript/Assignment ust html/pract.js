var book= {
    name: 'bgj',
    year: 2000,
    author: 'me'
};
console.log(book.name);
console.log(book["author"]);

function first(a){
    console.log("this is first function");
    setTimeout(function(){
        console.log("entry set time out")
        second();
        console.log("after set time out")
    },1000);
}

    function second(){
        console.log("this is second fun");

    }
first(second);

var primes= [2,3,5,7,11,13,21,"22",31];
var my=primes.toLocaleString();
console.log(my);
console.log(primes[7]);
primes[9]=333;
console.log(primes);
primes[8]=31651;
console.log(primes);

var a=10;
var b=10;
if(a===b){
    console.log("equal");

}
else{
    console.log("not equal");
}
var a = [1,2,3,4,5,6,7,8];
console.log(a.splice(4)); // Returns [5,6,7,8]; a is [1,2,3,4]
console.log(a);
console.log(a.splice(1,2));
console.log(a); // Returns [2,3]; a is [1,4]
console.log(a.splice(1,1)); // // Returns [4]; a is [1]
var a1 = [1,2,3,4,5,6,7,8];
console.log(a1.slice(1,3));

var a2=[1,2,3,4];
var b=a2.map(function(x){
    return x*x;

})

console.log(b);
console.log(a2);
var c=a2.filter(function(x) {
    return x>2;
});
console.log(c);
var sum=0;
a2.forEach(function(a){
  return  sum+=a;
});
console.log(sum);

var a3= [1,2,3,4,5]
var sum = a3.reduce(function(x,y) { return x+y }, 0); 
console.log(sum);
person=
{
    name: 'suma',
    age: 12,
}
for(var a in person){
    console.log(person[a]);
}
for(var b of a3){
    console.log(b);
}
var a4= [1,2,3,4,5]
for(var a in a4){
    console.log(a4[a]);
}
var a5= [1,2,3,4,5]
var k=1;
a5.forEach(function(x){
 return k=k*x;
})
console.log(k);

var str="hello how are you?";
var m=str.split( "o",3 );
console.log(m);

// window.alert('hii');
// window.prompt("enter name")
// var k=confirm("r u human");
// console.log(k)
var todayDate = new Date();
console.log(todayDate);

console.log(todayDate.getDate());
console.log(todayDate.getFullYear());
var date= new Date(0);
console.log(date);
var date1=new Date(2019,9,16,20,17,33,0);
console.log(date1);
var date2=new Date("sep 16,2019 8:18:00");
console.log(date2)
console.log(Date.now());
var date4= new Date("February 48, 2018 12:30 PM")
 var m=Date.parse(date4);
console.log(m);
var date = "February 18, 2018 12:30 PM"; 
      
// Calling parse function on input date string. 
var msec = Date.parse(date); 
console.log(msec);

function ar(x){
    return x;
}
var m=ar(4);
console.log(m);

var k = function(x){
    return x;
}
var m = k(49);
console.log(m);

 (function(x){
 l=x;
})(5);
console.log(l);
var o = (x)=>{return x;}
var p =o(4);
console.log(p);
let me = document.write("laxmi");
console.log(me);
console.log(document.getElementById('na'));
let object = document.createElement('h3');
object.textContent='hii';
console.log(object);
document.body.appendChild(object);
let o1 = document.getElementsByName('hi');
console.log(o1);
let o2 = document.getElementById('na');
console.log(o2);
let o3 = document.querySelector('#na');
console.log(o3);


