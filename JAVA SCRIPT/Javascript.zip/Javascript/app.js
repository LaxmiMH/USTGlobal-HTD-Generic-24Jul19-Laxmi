var todaysDate=new Date();
console.log(todaysDate);

var month=todaysDate.getMonth();
console.log(month)

var date2=new Date  (2018,11,24,10,33,30,0);
console.log(date2);
var date1=new Date("october 13,2014,11:13:0");
console.log(date1);
var date=new Date(0);
console.log(date);
var months=['jan','feb','march','april','may','june','july','august','september','october','november','december'];
var day=['sun','mon','tue','wed','thur','fri','sat'];
console.log("month="+months[todaysDate.getMonth()]);
console.log("Day="+day[todaysDate.getDay()]);
console.log(Math.PI);
console.log(Math.floor(4.5));
console.log(Math.ceil(4.5));
console.log(Math.round(4.5));
console.log(Math.pow(4,5));
console.log(Math.random()*100);
console.log("0");
console.log(Math.ceil(Math.random()*100));
console.log(Math.floor(Math.random()*100));
var num = 10;
var num1 = '10';
if(num===num1){

    console.log("equal");
}
else{
    console.log("not equal");
}
console.log(typeof num);
console.log(typeof num1);
var number;
console.log(typeof number);
var  fruits=['orange','apple'];
console.log(typeof fruits);
console.log(typeof(null));
var boolean=true;
console.log(typeof boolean);
var age=21;
var age1=(age>=18)?'adult':'child';
console.log(age1);
var age2=(age>21)?'elder':(age===21)?'equal':'small';
console.log(age2);
var num=22;
num+=10;
console.log(num);
num%=2;
console.log(num);

var employee=[{name:'varun',age:23},{name:'deepika',age:25},{name:'bhgat',age:90}];
for(i=0;i<=employee.length;i++){
console.log(employee[i]);

}
console.log(employee[0].name);
console.log(employee[0]);
var hobbies=['cricket','painting','tavaelling','jumping',' '];
for(var value of hobbies){
    console.log(value);

}
for(var index in hobbies){
    console.log(hobbies[index]);
    console.log(index);
}
var person={
    name:'DBOSS',
    age:20,

}
for( var index in person){
    console.log(person[index]);
}
for(var keys in person){
    console.log(person[keys]);
}
var message='hello';
console.log(message);
var message=message+'world';
console.log(message);
var message1=message;
console.log(message1);
var message='hi';
console.log(message);

var person={
    name:'samantha',
    age:30,
    color:'white'
}
console.log(person);
person.name='kajal';
console.log(person);
var person1=person;
console.log(person1);
person1.name='rajni';
console.log(person);
console.log(person1);
var person2={
    name:'samantha',
    age:30,
    color:'white'
}
console.log(person2);
function first(){
    setTimeout(function(){
    console.log('first');
    
    },1000);
}
function second(){
    console.log('se');
    
}
first();
second();


function first(third){
    setTimeout(function(){  /*it go to web api*//*so it first executes this is first then excutes settimeout*/
    console.log('first');
    third();
    },1000);
    console.log("this is first");
}
function second(){
    console.log('se');   
}
first(second);

function f1(call){
    console.log('first method');
    call();
    console.log('third method');
}
function f2(){
    console.log('second method');
}
f1(f2);
















