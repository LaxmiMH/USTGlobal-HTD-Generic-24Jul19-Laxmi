document.getElementById('listid').innerHTML=
            ` <ol>
            <li>one</li>
            <li>two</li>
            <li>three</li>
            <li>four</li>
            <li>five</li>
        </ol>
    
<ol type="A">
    <li>one</li>
    <li>two</li>
    <li>three</li>
    <li>four</li>
    <li>five</li>
</ol>

<ol type="I">
        <li>one</li>
        <li>two</li>
        <li>three</li>
        <li>four</li>
        <li>five</li>
    </ol>

    <ol type="a">
            <li>one</li>
            <li>two</li>
            <li>three</li>
            <li>four</li>
            <li>five</li>
        </ol>


        <ol type="i">
                <li>one</li>
                <li>two</li>
                <li>three</li>
                <li>four</li>
                <li>five</li>
            </ol>


----------------------------------------------------------------------------------------------
    

<ul>
        <li>ji</li>
        <li>hu</li>
        <li>mk</li>
        <li>ol</li>
        <li>jik</li>
    </ul>


<ul type="square">
    <li>ji</li>
    <li>hu</li>
    <li>mk</li>
    <li>ol</li>
    <li>jik</li>
</ul>

<ul type="circle">
        <li>ji</li>
        <li>hu</li>
        <li>mk</li>
        <li>ol</li>
        <li>jik</li>
    </ul>

    <ul type="disc">
            <li>ji</li>
            <li>hu</li>
            <li>mk</li>
            <li>ol</li>
            <li>jik</li>
        </ul>






`;