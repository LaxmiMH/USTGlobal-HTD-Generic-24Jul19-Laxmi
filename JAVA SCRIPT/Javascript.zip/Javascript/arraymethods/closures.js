function sum(a,b){
    function addsum(){
        return a+b;
    }
    return addsum;
}
var addFun= sum(10,20);
var total=addFun();
console.log('Total',total)
console.log(window);
console.log(this);
console.log(this===window);
var name="rakshit shetty";
console.log(window.name);
console.log(this.name);
var person={
    name:'Darshan',
    age:50,
    getName:function(){
        console.log('getname method'+  this.name);/*this is not window inside method*/
        console.log(window);
        getData();
        function getData(){
            console.log('get data method'+ this.name);/*this is window*/
        }
        return this.name;
    }
    
    }
    var name1=person.getName();
    console.log(name1);
    for(var i=0;i<5;i++){
        console.log(i);
    }
    console.log('value of i is'+i);
    for(let j=0;j<5;j++){
        console.log(j);
    }
   /* console.log(j);*/
    var hobbies=['dancing','singing','cricket'];/*declaration+initilization*/
    console.log('hobbies'+hobbies);
    var hobbies=['numismatics'];
  var  hobbies=['ch'];/*redeclaration*/
    console.log(hobbies);
    hobbies=['singing'];
    console.log('/////');
    let fruits=['orange','banana'];
    console.log(fruits);
  fruits=['jackfruit'];//reinitilization is posiible in let keyword
    console.log(fruits);
    /*const name='suman';
    console.log(name);
    const name='jaya';
    console.log(name);*/

    const items=['lipstick','kajal','deo','wallet'];
   console.log(items);
//   const items=['bag','book'];/*re declartion and also initilization is not possible*/
//     console.log(items);
    items[1]=['book','bag'];
  console.log(items);

    

