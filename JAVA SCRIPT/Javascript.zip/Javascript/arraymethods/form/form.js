function validateForm(){
     let formData=document.forms[0];
   //  console.log(formData.uname.value);
  let username= formData.uname.value;
  let passwordValue=formData.passwrd.value;
  

  if(username.length>4)
      {
        formData.uname.style.border='2px solid green';
        document.getElementById('message').innerHTML='user name is valid';
      }
      else{
        formData.uname.style.border='2px solid red';
        document.getElementById('message').innerHTML='name invalid';
         
    formData.loginSubmit.disabled=true;
      }

       if(passwordValue.length>7){
    formData.passwrd.style.border='1px solid green';
    document.getElementById('message1').innerHTML='password  is valid';
  
  

        }
        else{
          formData.passwrd.style.border='4px solid red';
          document.getElementById('message1').innerHTML='password invalid';
           
      formData.loginSubmit.disabled=true;
        }
        formData.loginSubmit.disabled=false;
    //   console.log('success');
    
//    else {
//       formData.uname.style.border='4px solid red';
//       formData.passwrd.style.border='4px solid red';
//       document.getElementById('message').innerHTML='user name is invalid';
     
//       document.getElementById('message1').innerHTML='password is invalid';
//       formData.loginSubmit.disabled=true;
     
//   }
// }
// function validateForm1(){
//     let formData=document.forms[0];
//   let password=formData.passwrd.value;
//   if(password.length>4){
//       console.log('success');
//       formData.passwrd.style.border='2px solid green';
//   }else{
//       formData.passwrd.style.border='4px solid red';
//   }
 }

