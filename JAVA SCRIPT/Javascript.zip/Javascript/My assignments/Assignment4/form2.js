document.getElementById('formid').innerHTML=
      `<form action="">
        <div>
    <label for="Name">Name</label><br>
    <input type="text" name="name" id="name" required placeholder="enter name" >
</div>
<div>
    <label for="psd">password</label><br>
    <input type="password" name="psd" id="psd"required>
</div>
<div>
    <label for="em">email</label><br>
    <input type="email" name="em" id="em">
</div>
<div>
    <label for="">hidden</label>
<input type="hidden" name="">
</div>
<div>
    <label for="mob">mobile number</label><br>
    <input type="tel" name="mob" id="mob">
     </div><br>
     <div>
         <label for="gn">Gender</label><br>
         <input type="radio" name="gn" id="gn">Male
         <input type="radio" name="gn" id="gn">Female
         <input type="radio" name="gn" id="gn">Others
     </div><br>
     <div>
            <label for="">Joining month</label>
         <select name="month" id="month">
         <option value="0" selected disabled>select</option>
     <option value="Jan">january</option>
     <option value="Feb">february</option>
     <option value="Mar">march</option>
     <option value="Apr">april</option>
     <option value="May">may</option>
     <option value="Jun">june</option>
     <option value="Jul">july</option>
     <option value="Aug">August</option>
     <option value="Sep">September</option>
     <option value="oct">october</option>
     <option value="Nov">november</option>
     <option value="Dec">december</option>
    </select>
    </div>
    <div><br>
        <label for="">Upload a Document</label><br><br>
        <input type="file" name="upload" id="upload">
    </div>
    <div><br>
        <div>
            
        <input type="checkbox" name="chk" id="chk">
        <label for="">I agree</label>
        
    </div>
    <!-- <input type="submit" value="submit"> -->
    
    <button type="submit">submit</button>&nbsp;
    <button type="reset">reset</button>
        </div>

</form>`

