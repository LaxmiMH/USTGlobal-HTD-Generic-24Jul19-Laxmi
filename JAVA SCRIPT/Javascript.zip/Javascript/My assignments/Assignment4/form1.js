 document.getElementById('formid').innerHTML=
 `<form action="">
    <div>
        <label for="">First Name</label><br>
        <input type="text" name="" id="">
    </div><br>
    <div>
        <label for="">Last Name</label><br>
        <input type="text">
    </div><br>
    <div>
        <label for="">Company Name</label><br>
        <input type="text" name="" id="">
    </div><br>
    <div>
        <label for="">Email id</label><br>
        <input type="email" name="" id="">
    </div><br>
    <div>
        <label for="">Date of joining</label><br>
        <input type="datetime" name="" id="">
    </div><br>
    <div>
        <label for="k">Gender</label><br>
        <input type="radio" name="k" id="k">male
        <input type="radio" name="k" id="k">female
        <input type="radio" name="k" id="k">others
    </div><br>
    <div>
        <label for="gn">Skills</label><br>
        <input type="checkbox" name="gn" id="gn">java <br>
        <input type="checkbox" name="gn" id="gn">sql <br>
        <input type="checkbox" name="gn" id="gn">j2ee <br>
        <input type="checkbox" name="gn" id="gn">hibernet <br>
    </div><br>
    <center>
    <button type="submit">submit</button>
    
    <button type="reset">reset</button>
</center>
</form>`