// function addRow()
// {
    
//     var name = document.getElementById('name').value;
//      var password = document.getElementById('password').value;
      
//       if(!name || !password)
//       {
//       alert("wrong password");
//       return;
//       }
      
//       var table = document.getElementsByTagName('table')[0];
      
    
//       var newRow = table.insertRow(table.rows.length/2+1);
      
     
//       var cel1 = newRow.insertCell(0);
//       var cel2 = newRow.insertCell(1);
 
      
    
//       cel1.innerHTML = name;
//       cel2.innerHTML = password;
      
// }









//  var button=document.getElementById("button");
//  button.addEventListener("click",displaydetails);
 
 function addRow(){
     var name=document.getElementById("name").value;
     var password=document.getElementById("pass").value;

     if(!name || !password){
         alert("please enter name and password");
         return;
     }
     
     var table=document.getElementsByTagName("table")[0];



     var newRow = table.insertRow(table.rows.length/2+1);

     
     var cel1=newRow.insertCell(0);
     var cel2=newRow.insertCell(1);
     
     cel1.innerHTML=name;
     cel2.innerHTML=password;
    
     
 }
// function displayDetails()
// {
    
//     var name = document.getElementById('name').value;
//      var password = document.getElementById('password').value;
      
//       if(!name || !password)
//       {
//       alert("wrong password");
//       return;
//       }
      
//       var table = document.getElementsByTagName('table')[0];
      
    
//       var newRow = table.insertRow(table.rows.length/2+1);
      
     
//       var cel1 = newRow.insertCell(0);
//       var cel2 = newRow.insertCell(1);
 
      
    
//       cel1.innerHTML = name;
//       cel2.innerHTML = password;
      
// }