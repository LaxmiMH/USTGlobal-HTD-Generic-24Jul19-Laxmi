
let tableElement=document.createElement('table');
let tr1=document.createElement('tr');
let trd1=document.createElement('td');
trd1.textContent='Name';
let trd2=document.createElement('td');
trd2.textContent='Age';
tr1.appendChild(trd1);
tr1.appendChild(trd2);

let tr2=document.createElement('tr');
let trd3=document.createElement('td');
trd3.textContent='John';
let trd4=document.createElement('td');
trd4.textContent='14';
tr2.appendChild(trd3);
tr2.appendChild(trd4);

let tr3=document.createElement('tr');
let trd5=document.createElement('td');
trd5.textContent='Dinga';
let trd6=document.createElement('td');
trd6.textContent='20';
tr3.appendChild(trd5);
tr3.appendChild(trd6);

let tr4=document.createElement('tr');
let trd7=document.createElement('td');
trd7.textContent='Sundri';
let trd8=document.createElement('td');
trd8.textContent='22';
tr4.appendChild(trd7);
tr4.appendChild(trd8);


let a=tableElement.appendChild(tr1);
console.log(a);
tableElement.appendChild(tr2);
tableElement.appendChild(tr3);
tableElement.appendChild(tr4);
document.body.appendChild(tableElement)
