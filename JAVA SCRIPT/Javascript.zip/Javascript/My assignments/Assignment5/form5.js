function validate(){
    let data=document.forms['empform'];
    let name=data.name.value;
    let password=data.pass.value;
    document.getElementById('tableid').innerHTML=
    ` <table>
    <tr>
        <td>name</td>
        <td>password</td>
    </tr>
     </table>` 
     
}