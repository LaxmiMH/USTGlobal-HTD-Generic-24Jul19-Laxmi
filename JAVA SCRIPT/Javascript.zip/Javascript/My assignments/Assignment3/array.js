var hobbies=['sing','dance','cricket','football','mono','kmjhjfjjgh'];
hobbies.forEach(function(value,index){
    if(value.length>7)  /*it checks no of letters i.e length so football is 8 so its execute*/
    console.log(value);
});
console.log(myName);
 var myName ='cs';
console.log(myName);
/*function hoist*/
function getAge()
{

    console.log(age);
    var age=10;
    console.log(age);
}
getAge();

var hobbies=['sing','dance','cricket','football'];
var checkArray=Array.isArray(hobbies);
console.log('is array=' +checkArray)
var checkincludes=hobbies.includes('cricket');
console.log(checkincludes);
hobbies.push('kabbaddi','volley');/* it add elements to after last index*//*it ouput is newlength=6*/
console.log(hobbies);
hobbies.pop();
console.log(hobbies);
hobbies.unshift('shopping','skipping')
console.log(hobbies);
hobbies.shift();
console.log(hobbies);
hobbies.join('-');
console.log(hobbies);
hobbies.splice(1,1,'haircut');
console.log(hobbies);
var hobbies1=hobbies.slice(1,4);
console.log(hobbies1);
var index =hobbies.indexOf('football');
console.log(index);
var index =hobbies.indexOf('ball');
console.log(index);
var index =hobbies.indexOf('cricket',4);
console.log(index);
var numbers=[10,20,30,40,50];
var number1=numbers.map(function(value){
    value=value+10;
    return value;
})
console.log(number1);
 var number2=numbers.filter(function(value){
     return value>10;
 }) 
console.log(number2);//using fatarray function
var number1=numbers.map((value,index)=>{
    value=value+10;
    return value;
})
console.log(number1);
/*map and filter create new array after execution*/
var items=[{name:'lipstick',price:95,id:1},{name:'perfume',price:500,id:2},{name:'watch',price:1000,id:3},{name:'shoe',price:2000,id:4}]
/*items.map(function(item){
    item.price=item.price+100;
    return item.price;
})*/
console.log(items);
var filtereditems=items.filter(function(item){
    var itemFilter=item.price>100 && item.name.length>6;
    return itemFilter;
});
console.log(filtereditems);
var hobbies1=['sing','dance','cricket','football','swimming'];
var ch=Array.isArray(hobbies1);
console.log(ch);
var ch1=hobbies1.includes('sing',0);
console.log(ch1);
console.log(hobbies1.push('chatting'));
console.log(hobbies1);
console.log(hobbies1.pop());
console.log(hobbies1);
console.log(hobbies1.unshift('whatsapp','facebbok'));
console.log(hobbies1);
console.log(hobbies1.shift());
console.log(hobbies1);
console.log(hobbies1.splice(1,2,'jasmine','baby'));
console.log(hobbies1.slice(1,4));
console.log(hobbies1.join('_'));

